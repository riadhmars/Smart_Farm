#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include <string.h>



void
on_valider_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;

GtkWidget *input1,*input4;

GtkWidget *JOUR;
GtkWidget *MOIS;
GtkWidget *ANNEE;
GtkWidget *radio1;
GtkWidget *radio2;
GtkWidget *radio3;
GtkWidget *radio4;
GtkWidget *label19;

GtkWidget *output;


GSList *List;

GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

char msg[500];

FILE *f=NULL;



input1=lookup_widget(object_graphique,"idcap");

input4=lookup_widget(object_graphique,"marque");
JOUR=lookup_widget(object_graphique,"jour");
MOIS=lookup_widget(object_graphique,"mois");
ANNEE=lookup_widget(object_graphique,"annee");
radio1=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton1");
radio2=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton2");
radio3=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton3");
radio4=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton4");

output=lookup_widget(object_graphique,"label19");




List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio1)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data)));}

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio3)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data))); 
else {List = g_slist_next(List); 
strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data)));}



strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));

int i,k=0,j=0;
for (i=0;i<strlen(c.idcapteur);i++)
if (      (isspace(c.idcapteur[i])!=0) ||  (c.idcapteur[i]=='*')    ) k++;
for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir ID capteur "); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==1) 
	{sprintf(msg,"Ce capteur existe ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if (k!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n dans le champ ID du capteur");

	gtk_label_set_text(GTK_LABEL(output),msg); }
else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }			
			
else if (strcmp(c.marque,"")==0) {sprintf(msg,"Veuillez saisir la marque du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else { sprintf(msg,"capteur ayant l ID: %s\n ajoutee avec succes",c.idcapteur); gtk_label_set_text(GTK_LABEL(output),msg);
	ajouter_capteur(c); }

}










void
on_valider2_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;
GtkWidget *input;

GtkWidget *output;
char msg[200];




output=lookup_widget(object_graphique,"label18");
input=lookup_widget(object_graphique,"idcapsup");
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));

if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir ID capteur à supprimer"); gtk_label_set_text(GTK_LABEL(output),msg);}

/*else if (rechercher(c)==0) 
	{ sprintf(msg,"Ce capteur n'existe pas ");gtk_label_set_text(GTK_LABEL(output),msg); }*/

else {supprimer_capteur(c);sprintf(msg,"Donnees du capteur ayant l id : %s \n sont supprimées", c.idcapteur);gtk_label_set_text(GTK_LABEL(output),msg); }	 




}















void
on_cvmdf_clicked                       (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{

GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;
GtkWidget *input;
GtkWidget *cmarquemdf;
GtkWidget *output;
GtkWidget *idcapmdf;
char msg[200];

capteur c;


input=lookup_widget(object_graphique,"idcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
combobox1=lookup_widget(object_graphique,"combobox1");
combobox2=lookup_widget(object_graphique,"combobox2");
cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");
output=lookup_widget(object_graphique,"label17");



	strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(cmarquemdf)));
int i,k=0,j=0;

for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir l ID du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if ( (    gtk_combo_box_get_active(GTK_COMBO_BOX(combobox1))<0   )|| gtk_combo_box_get_active(GTK_COMBO_BOX(combobox2))<0 || strcmp(c.marque,"")==0 ) 

gtk_label_set_text(GTK_LABEL(output),"veuillez saisir les donnees");

else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else 	
{		
	strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(c.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmj));
	c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmm));
	c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cma));	
	modifier_capteur(c);
	sprintf(msg,"Donnes du capteur ayant l id : %s \n sont modifiees",c.idcapteur);
	gtk_label_set_text(GTK_LABEL(output),msg) ;	
}


}


void
on_caffmdf_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
capteur c;
capteur e;

GtkWidget *input;
GtkWidget *output;
GtkWidget *label17;
GtkWidget *cmarquemdf;
GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;


char msg[200];

combobox1=lookup_widget(object_graphique,"combobox1");
combobox2=lookup_widget(object_graphique,"combobox2");


cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");


input=lookup_widget(object_graphique,"idcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
output=lookup_widget(object_graphique,"label17");
if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir l ID du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}
else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else {	e=idrechercher(c);
	sprintf(msg,"Modification des donnes du capteur\n ayant l id : %s ",c.idcapteur);
	/*"%s %s %s %s %d %d %d " , e.idcapteur,e.type,e.etat,e.marque,e.dda.jour,e.dda.mois,e.dda.annee);*/
	gtk_label_set_text(GTK_LABEL(output),msg);
	

	
	if (strcmp(e.type,"temperature")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),0);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),1);
	if (strcmp(e.etat,"fonctionnel")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),0);
	else if (strcmp(e.etat,"en-arret")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),1);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),2);
	
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmj),e.dda.jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmm),e.dda.mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cma),e.dda.annee);
	gtk_entry_set_text(GTK_ENTRY(cmarquemdf),e.marque);	}

}















void
on_cafficher_clicked                   (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

treeview1=lookup_widget(object_graphique,"treeview1");
afficher_capteur(treeview1);
}


void
on_button1_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
valeur v;
capteur c;
GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *label76;
GtkWidget *radiobutton5;
GtkWidget *radiobutton6;
GtkWidget *calendar1;
guint *y;
guint *m;
guint *d;
  guint year, month, day;
char type[50];
char aaa[50];


entry1=lookup_widget(object_graphique,"entry1");
entry2=lookup_widget(object_graphique,"entry2");
label76=lookup_widget(object_graphique,"label76");

radiobutton5=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton5");
radiobutton6=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton6");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton5)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

strcpy(v.idcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(aaa,gtk_entry_get_text(GTK_ENTRY(entry2)));
v.val=atof(aaa);

///////////////////////////////
calendar1=lookup_widget(GTK_WIDGET(object_graphique),"calendar1");
gtk_calendar_get_date (GTK_CALENDAR (calendar1),
			 &year, &month, &day);

v.j=day;
v.m=month;
v.a=year;

////////////////////////////
int i,j=0;
for (i = 0;aaa[i] != '\0'; i++)
        if (isdigit(aaa[i])!= 0)
            j++;

c=idrechercher(c);


if (   strcmp(v.idcapteur,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir l ID du capteur");}
else if (rechercher(c)==0) { gtk_label_set_text(GTK_LABEL(label76),"ce capteur n existe pas");}
else if (strcmp(c.etat,"fonctionnel")!=0) {gtk_label_set_text(GTK_LABEL(label76),"Veuillez verifier que ce capteur est fonctionnel");}
else if (strcmp(c.type,type)!=0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez verifier le type correcte de ce capteur");}
else if (strcmp(aaa,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir la valeur ajoutée");}
else if (j==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir une valeur entiére");}
else { gtk_label_set_text(GTK_LABEL(label76),"Valeur ajoutée avec succès"); 
	if (strcmp(type,"temperature")==0) ajouter_temperature(v);
	else ajouter_humidite(v);}









}


void
on_button3_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul type
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
float min,max;
char type[50];

treeview3=lookup_widget(object_graphique,"treeview3");
entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");
radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

min=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
max=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"temperature")==0) afficher_temperature(treeview3);
else afficher_humidite(treeview3);



}


void
on_button4_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul capteur
GtkWidget *treeview3;
GtkWidget *entry5;
char id[50];
capteur c;

entry5=lookup_widget(object_graphique,"entry5");
treeview3=lookup_widget(object_graphique,"treeview3");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(c.idcapteur,id);
afficher_valeur_capteur(treeview3,c);


}


void
on_button5_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs probleme d un seul type hors un intervalle
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
v.vmax=0;v.vmin=0;
entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");
treeview3=lookup_widget(object_graphique,"treeview3");

radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"humidite")==0) afficher_valeur_probleme_hum(treeview3,v);
else afficher_valeur_probleme_temp(treeview3,v);




}


void
on_button6_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//changer type en def si hors l intervalle 
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
GtkWidget *label72;

label72=lookup_widget(object_graphique,"label72");

entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");


radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));
if (v.vmin==0 || v.vmax==0) gtk_label_set_text(GTK_LABEL(label72),"verifier les valeurs de l intervalle");
else if (strcmp(type,"humidite")==0) capteur_valeur_defecteux_hum(v);
else capteur_valeur_defecteux_temp(v);




}



void
on_button2_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//marque + de cap def 
term t;
char msg[500];
int k;
GtkWidget *label72;

label72=lookup_widget(object_graphique,"label72");

marques_def();
marques_def_nbr();
k=max_marque_def();

t=finale(t,k);
strcpy(msg,t.ter);
if (strcmp(msg,"//////////////*")==0) strcpy(msg,"aucun capteur defectueux");
gtk_label_set_text(GTK_LABEL(label72),msg);



}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



	GtkTreeIter iter;
	gchar* idcapteur;
	gchar* type;
	gchar* etat;
	gchar* marque;

	gchar* date;


	capteur c;
	
	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if ( gtk_tree_model_get_iter(model,&iter,path)) {
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&idcapteur,1,&type,2,&etat,3,&marque,4,&date,-1);
	strcpy(c.idcapteur,idcapteur);


	
	supprimer_capteur(c);
	afficher_capteur(treeview);
	

	}
}

