#include<gtk/gtk.h>
#include<string.h>


void
on_valider_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);






void
on_valider2_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);









void
on_cvmdf_clicked                       (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_caffmdf_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);










/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
*/







void
on_cafficher_clicked                   (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
