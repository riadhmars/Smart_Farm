#ifdef HAVE_CONGIG_H
#include <config.h>
#endif



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<capteur.h>
#include<gtk/gtk.h>

void ajouter_capteur(capteur c)
{

FILE *f;
f=fopen("capteurs.txt","a+");


if (f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d \n" , c.idcapteur,c.type,c.etat,c.marque,c.dda.jour,c.dda.mois,c.dda.annee);
fclose(f);
}
}

void supprimer_capteur(capteur c)
{

capteur c2;

FILE *f,*g;

f=fopen("capteurs.txt","r");
g=fopen("capteurs2.txt","w");

	if (f==NULL || g==NULL)
	return;
	else
	{
	while(fscanf(f,"%s %s %s %s %d %d %d \n",c2.idcapteur,c2.type,c2.etat,c2.marque ,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
	 {
	if (strcmp(c.idcapteur,c2.idcapteur)!=0) 

	fprintf(g, "%s %s %s %s %d %d %d \n" ,	c2.idcapteur,c2.type,c2.etat,c2.marque ,c2.dda.jour,c2.dda.mois,c2.dda.annee);

	
 	}
	fclose(f);
	fclose(g);
	remove("capteurs.txt");
	rename("capteurs2.txt","capteurs.txt");
	
	}

}


int rechercher(capteur c)
{
FILE *f;
capteur c2;
int k=0;


f=fopen("capteurs.txt","r");
if (f!=NULL) 
{ while(fscanf(f, "%s %s %s %s %d %d %d \n" ,	c2.idcapteur,c2.type,c2.etat,c2.marque ,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
       if (strcmp(c.idcapteur,c2.idcapteur)==0)
       {
	 k=1;
	}
}
fclose(f);
return(k);
}

capteur idrechercher(capteur c)
{
{

FILE *f;
capteur c2;
f=fopen("capteurs.txt","r");
if (f!=NULL) 
{ while(fscanf(f, "%s %s %s %s %d %d %d \n" ,c2.idcapteur,c2.type,c2.etat,c2.marque,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
       if (strcmp(c.idcapteur,c2.idcapteur)==0)
       {
	strcpy(c.idcapteur,c2.idcapteur);
	strcpy(c.type,c2.type);
	strcpy(c.etat,c2.etat);
	strcpy(c.marque,c2.marque);
	c.dda.jour=c2.dda.jour;
	c.dda.mois=c2.dda.mois;
	c.dda.annee=c2.dda.annee;
	}
}
fclose(f);
}
return(c);
}


void modifier_capteur(capteur c)
{

capteur c2;

FILE *f,*g;
f=fopen("capteurs.txt","r");
g=fopen("capteurs2.txt","w");
	if (f==NULL || g==NULL)
	return;
	else
	{
	while(fscanf(f,"%s %s %s %s %d %d %d \n",c2.idcapteur,c2.type,c2.etat,c2.marque ,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
	 {
	if (strcmp(c.idcapteur,c2.idcapteur)!=0) 
	fprintf(g, "%s %s %s %s %d %d %d \n" ,	c2.idcapteur,c2.type,c2.etat,c2.marque ,c2.dda.jour,c2.dda.mois,c2.dda.annee);
	else fprintf(g, "%s %s %s %s %d %d %d \n" ,	c.idcapteur,c.type,c.etat,c.marque ,c.dda.jour,c.dda.mois,c.dda.annee);

	
 	}
	fclose(f);
	fclose(g);
	remove("capteurs.txt");
	rename("capteurs2.txt","capteurs.txt");
	
	}

}

enum{
	EIDCAPTEUR,
	ETYPE,
	EETAT,
	EMARQUE,
	EDDA,
	COLUMNS
};



void afficher_capteur(GtkWidget *liste)


{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char type[50];
	char etat[50];
	char marque[50];
	date dda;
	char dateachat[50];
	char j[20],m[20],a[20];
	int jr,mo,an;
	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);//va prendre comme variable de la liste
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Etat",renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Date d'achat",renderer,"text",EDDA,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("capteurs.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("capteurs.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s %s \n",idcapteur,type,etat,marque,j,m,a)!=EOF)
{	strcpy(dateachat,"");
	strcat(dateachat,j);
	strcat(dateachat,"/");
	strcat(dateachat,m);
	strcat(dateachat,"/");
        strcat(dateachat,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR,idcapteur,ETYPE,type,EETAT,etat,EMARQUE,marque,EDDA,dateachat,-1);
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	
}

}




void ajouter_temperature(valeur v)
{
FILE *f;

f=fopen("temperature.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %d %d %d %.2f \n" , v.idcapteur,v.j,v.m,v.a,v.val);
fclose(f);
}
}

void ajouter_humidite(valeur v)
{
FILE *f;

f=fopen("humidite.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %d %d %d %.2f \n" , v.idcapteur,v.j,v.m,v.a,v.val);
fclose(f);
}
}


enum{
	EIDCAPTEUR2,
	EDATE,
	EVAL,
	ETYPE2,
	COLUMNS2
};



void afficher_temperature(GtkWidget *liste)


{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	strcpy(type,"temperature");
	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVAL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
	store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	
}

}


void afficher_humidite(GtkWidget *liste)


{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	strcpy(type,"humidite");

	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVAL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
	store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("humidite.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("humidite.txt","r");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	
}

}













void afficher_valeur_capteur(GtkWidget *liste,capteur c)


{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	

	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVAL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
	store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("humidite.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("humidite.txt","r");
	strcpy(type,"humidite");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
	if (strcmp(c.idcapteur,idcapteur)==0)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
	fclose(f);




	
}

	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
	if (strcmp(c.idcapteur,idcapteur)==0)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
	fclose(f);



	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	
}



}






void afficher_valeur_probleme_hum(GtkWidget *liste,vprob v)

{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	float vvv;

	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVAL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
	store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("humidite.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("humidite.txt","r");
	strcpy(type,"humidite");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
{	vvv=atof(val);	
	if (vvv>=v.vmax || vvv<=v.vmin)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
}
	fclose(f);
	
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
}	
}




void afficher_valeur_probleme_temp(GtkWidget *liste,vprob v)

{

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	float vvv;

	 store=NULL;
	 FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("ID Capteur",renderer,"text",EIDCAPTEUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVAL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
	store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
{	vvv=atof(val);	
	if (vvv>=v.vmax || vvv<=v.vmin)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
}
	fclose(f);
	
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
}	
}




/////////////////////////////////////////////////////



void modifier_capteur_en_defectueux(capteur c)
{

capteur c2;

FILE *f,*g;
f=fopen("capteurs.txt","r");
g=fopen("capteurs2.txt","w");
	if (f==NULL || g==NULL)
	return;
	else
	{
	while(fscanf(f,"%s %s %s %s %d %d %d \n",c2.idcapteur,c2.type,c2.etat,c2.marque ,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
	 {
	if (strcmp(c.idcapteur,c2.idcapteur)!=0) 
	fprintf(g, "%s %s %s %s %d %d %d \n" ,	c2.idcapteur,c2.type,c2.etat,c2.marque ,c2.dda.jour,c2.dda.mois,c2.dda.annee);
	else fprintf(g, "%s %s %s %s %d %d %d \n" ,c.idcapteur,c2.type,"defectueux",c2.marque ,c2.dda.jour,c2.dda.mois,c2.dda.annee);

	
 	}
	fclose(f);
	fclose(g);
	remove("capteurs.txt");
	rename("capteurs2.txt","capteurs.txt");
	
	}

}


void capteur_valeur_defecteux_hum(vprob v)
{
	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	float vvv;
	capteur c;
	FILE *f,*g;
	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
	{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
	{	vvv=atof(val);	
		if (vvv>=v.vmax || vvv<=v.vmin) {strcpy(c.idcapteur,idcapteur); modifier_capteur_en_defectueux(c);}
	}


	}
}




void capteur_valeur_defecteux_temp(vprob v)
{
	char idcapteur[50];
	char dateval[50];
	char val[50];
	char j[20],m[20],a[20];
	char type[50];
	float vvv;
	capteur c;
	FILE *f,*g;
	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
	{	vvv=atof(val);	
	if (vvv>=v.vmax || vvv<=v.vmin) {strcpy(c.idcapteur,idcapteur);modifier_capteur_en_defectueux(c);}
	}


}
}



/////////////////////////////////////////////
void marques_def()
{

capteur c2;

FILE *f,*g;
f=fopen("capteurs.txt","r");
g=fopen("captdef.txt","w");

	if (f==NULL || g==NULL)
	return;
	else
	{
	while(fscanf(f,"%s %s %s %s %d %d %d \n",c2.idcapteur,c2.type,c2.etat,c2.marque ,&c2.dda.jour,&c2.dda.mois,&c2.dda.annee)!=EOF)
	 {
	if (strcmp("defectueux",c2.etat)==0)  fprintf(g, "%s \n" ,	c2.marque );
 	}
	fprintf(g, "//////////////");
	fclose(f);
	fclose(g);	
	}
}

void marques_def_nbr()
{

capteur c2;
capteur c;
FILE *f,*g,*b;
f=fopen("captdef.txt","r+");
g=fopen("captdef.txt","r+");
b=fopen("captdefnbr.txt","w");
int i, j, l, l1, l2;int count = 0, count1 = 0;
char str[500] ,sub[500];
str[0]= '\0';
	if (f==NULL || g==NULL || b==NULL)
	return;
	else
	{

	while(fscanf(f, "%s \n" ,c2.marque )!=EOF)
		{strcat(str,c2.marque);strcat(str,"*");}
		fclose(f);
l1 = strlen(str);
while(fscanf(g, "%s \n" ,sub )!=EOF)
	{
	l2 = strlen(sub);
	strcat(sub,"*");
	l2++;
	count1=0;
	count=0;	
	for (i = 0; i < l1;)
    {
        j = 0;
        count = 0;
        while ((str[i] == sub[j]))
        {
            count++;
            i++;
            j++;
        }
        if (count == l2) 
        { 
            count1++;                                   
            count = 0;
        }
        else
            i++;
    }
if (count1!=0) {sub[l2-1]='\0';fprintf(b, "%s %d \n" ,	sub,count1);}
}
		


	fclose(f);
	fclose(g);
	fclose(b);	
	}
}

int max_marque_def()
{
int j,i=0;
FILE *b;
b=fopen("captdefnbr.txt","r");
char test[50];

	if (b==NULL)
	return;
	else
	{
	while(fscanf(b,"%s %d",test,&j)!=EOF)
		{ if (j>i) i=j;	}
fclose(b);
}

return(i);
}


term finale(term t ,int max)

{
int j;
FILE *b;
b=fopen("captdefnbr.txt","r");
char str[200];
char str2[500];
char test2[50];
test2[0]= '\0';
t.ter[0]= '\0';
	if (b==NULL)
	return;
	else
	{
	while(fscanf(b,"%s %d ",test2,&j)!=EOF)
		if (j==max) { sprintf(str, "la marque %s : %d capteurs defectueux \n",test2, j); strcpy(str2,str); }
fclose(b);

}

strcpy(t.ter,str2);
return(t);


}


