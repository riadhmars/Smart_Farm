/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



	GtktreeIter iter;
	gchar* idcapteur;
	gchar* type;
	gchar* etat;
	gchar* marque;

	gchar* date;


	capteur c;
	
GtkTreeModel *model =gtk_tree_view_get_model(treeview);
	if ( gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&idcapteur,1,&type,2,&etat,3,&marque,4,&date,-1);
	strcpy(c.idcapteur,idcapteur);
	strcpy(c.type,type);
	strcpy(c.etat,etat);
	strcpy(c.marque,marque);
	strcpy(c.dda.jour,j);
	strcpy(c.dda.mois,m);
	strcpy(c.dda.annee,a);
	strcat(date,strcpy(j,jr));
	strcart(date,"-");
	strcat(date,strcpy(m,mo));
	strcart(date,"-");
        strcat(date,strcpy(a,an));
	
	
	

afficher_capteur(treeview);

}
}
*/
	f=fopen("humidite.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	strcpy(type,"humidite");
	f=fopen("humidite.txt","r");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
		{if (strcmp(c.idcapteur,idcapteur)==0)
		 {	strcpy(dateval,"");
			strcat(dateval,j);
			strcat(dateval,"/");
			strcat(dateval,m);
			strcat(dateval,"/");
			strcat(dateval,a);
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,EIDCAPTEUR3,idcapteur,ETYPE3,type,EDATE3,dateval,EVAL3,val,-1);
			}
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}






1 temperature fonctionnel a 1 1 2020 
2 temperature fonctionnel a 1 1 2020 
3 temperature fonctionnel b 1 1 2020 
4 temperature fonctionnel b 1 1 2020 
5 temperature fonctionnel b 1 1 2020 
6 temperature fonctionnel c 1 1 2020 
7 temperature fonctionnel c 1 1 2020 
8 temperature fonctionnel d 1 1 2020 
9 temperature fonctionnel d 1 1 2020 
11 humidite fonctionnel d 1 1 2020 
12 humidite fonctionnel d 1 1 2020 
13 humidite fonctionnel c 1 1 2020 
14 humidite fonctionnel c 1 1 2020 
15 humidite fonctionnel c 1 1 2020 
16 humidite fonctionnel b 1 1 2020 
17 humidite fonctionnel b 1 1 2020 
18 humidite fonctionnel b 1 1 2020 
19 humidite fonctionnel a 1 1 2020 




	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",idcapteur,j,m,a,val)!=EOF)
{	vvv=atof(val);	
	if (vvv>=v.vmax || vvv<=v.vmin)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EIDCAPTEUR2,idcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
}
	fclose(f);



/*(	(strcmp(c.type,"temperature")!=0) && (strcmp(c.type,"humidite")!=0) )&&( (strcmp(c.etat,"fonctionnel")!=0) &&
 (strcmp(c.etat,"en-arret")!=0) && (strcmp(c.etat,"defectueux")!=0)	)*/
