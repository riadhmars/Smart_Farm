#include <gtk/gtk.h>


void
on_button_tr_ajouter_clicked           (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_treeview1_tr_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modifiet_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_supprime_TR_clicked                 (GtkWidget      *gest_trou,
                                        gpointer         user_data);

void
on_button_chercher_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_AcceuilGestionTroupeau_clicked      (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_button_Actualise_Troupeau_clicked   (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_button_ret_tr_clicked               (GtkWidget        *gest_trou,
                                        gpointer         user_data);
///////////////////////////////////////////////////////////

void
on_Retour_fc_clicked                   (GtkWidget        *gest_fact,
                                        gpointer         user_data);

void
on_Ajouter_fc_clicked                  (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_treeview1_fc_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Modifier_fc_clicked                 (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_checkbutton1_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AcceuilGestionFacture_clicked       (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Actualiser_fc_clicked               (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Supp_fc_clicked                     (GtkWidget        *gest_fact,
                                        gpointer         user_data);

void
on_Chercher_fc_clicked                 (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Retour_fc_clicked                   (GtkWidget        *gest_fact,
                                        gpointer         user_data);


