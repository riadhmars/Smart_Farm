#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "CRUD.h"
#include <gtk/gtk.h>
 



   enum{
	EIDENTIFIANT_TR,
	ETYPE_TR,
	ESEXE_TR,
	ED_N_TR,
	EPOIDS_TR,
	EBUDGET_TR,
	/*EREF,
	ENOM,
	ENUM,
	EPROD,
	EQUANT,
	EMANT,
	DAJOUT,*/
	COLUMNS,
       }; 



/********************************************** Gestion de Troupeau ******************************/ 

  void Ajouter_Troupeau(Troupeaux TR)
 {
   FILE *F;
   F=fopen("Troupeau.txt","a+");
  if(F!=NULL)
    {
   fprintf(F,"%s %s %s %s %d %s \n",TR.identifiant_tr,TR.type_tr,TR.sexe_tr,TR.d_n_tr,TR.poids_tr,TR.budget_tr);
   fclose(F);
    }
  }



  int Exist_Troupeau(char *identifiant_tr)
 {
   FILE*F=NULL;
   Troupeaux TR;
   F=fopen("Troupeau.txt","r");
   while(fscanf(F,"%s %s %s %s %d %s \n",TR.identifiant_tr,TR.type_tr,TR.sexe_tr,TR.d_n_tr,&TR.poids_tr,TR.budget_tr)!=EOF)
   {
   if(strcmp(TR.identifiant_tr,identifiant_tr)==0)return 1;
   }
   fclose(F);
   return 0;
  }


  void Supprimer_Troupeau(char* identifiant_tr)
 {
    Troupeaux TR2;	 
    FILE *F,*Fich;
    F = fopen("Troupeau.txt","r");
    Fich = fopen("TmpTroupeau.txt","w");
    if(F ==NULL || Fich==NULL)
     {
	return;
     }
    else{
    while(fscanf(F,"%s %s %s %s %d %s \n",TR2.identifiant_tr,TR2.type_tr,TR2.sexe_tr,TR2.d_n_tr,&TR2.poids_tr,TR2.budget_tr)!=EOF)
     { 
     if(strcmp(identifiant_tr,TR2.identifiant_tr)!=0)
       { 
     fprintf(Fich,"%s %s %s %s %d %s \n",TR2.identifiant_tr,TR2.type_tr,TR2.sexe_tr,TR2.d_n_tr,TR2.poids_tr,TR2.budget_tr); 
       }
     }
    fclose(F);
    fclose(Fich);
    remove("Troupeau.txt");
    rename("TmpTroupeau.txt","Troupeau.txt");
        }
 }





/****************************************** Treeview Troupeau ********************************/

  int Afficher_Troupeau(GtkWidget *liste, char *l)
  {     

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de 		chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son 		attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de 		treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	 char identifiant_tr[20];
         char type_tr[20];
         char sexe_tr[20];
         char d_n_tr[20];
         int poids_tr;
         char budget_tr[20];

	int nt=0;

	
	 store=NULL;
	 FILE *F;

	store=gtk_tree_view_get_model(liste);//va prendre comme variable de la liste
	if(store==NULL)
	{ 
	
	renderer = gtk_cell_renderer_text_new (); //cellule contenant du texte
	column = gtk_tree_view_column_new_with_attributes("   Identifiant   ", renderer,"text",EIDENTIFIANT_TR,NULL);//creation d'une 		colonne avec du texte
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);//associer la colonne à l'afficher (GtkTreeView);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Type   ",  renderer,"text",ETYPE_TR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Sexe   ", renderer,"text",ESEXE_TR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Date de naissance   ", renderer,"text",ED_N_TR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Poids   ", renderer,"text",EPOIDS_TR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Budget   ", renderer,"text",EBUDGET_TR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}

	//lA liste contient 6 colonnes de type chaine de caracteres
	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
	F=fopen(l,"r");
	if(F==NULL)
	{
	return;
	}
	else
	{ Troupeaux TR;
   	F=fopen(l,"a+");
   	while(fscanf(F,"%s %s %s %s %d %s \n",identifiant_tr,type_tr,sexe_tr,d_n_tr,&poids_tr,budget_tr)!=EOF)
	{       nt++;

        	
	gtk_list_store_append (store, &iter);//variable intermediaire store
	gtk_list_store_set (store, &iter,EIDENTIFIANT_TR,identifiant_tr,ETYPE_TR,type_tr,ESEXE_TR,sexe_tr,ED_N_TR,d_n_tr,EPOIDS_TR,
	poids_tr,EBUDGET_TR,budget_tr, -1);//correspondre chaque champ a mon variable
	}
	fclose(F);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
return nt;
   }


   int Chercher_Troupeau(GtkWidget *liste,char *l ,char* type_tr)
   {

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;
	FILE *F;
 	int nb=0;
	int j;
	Troupeaux TR;

        
	/* Creation du modele */
       store = gtk_list_store_new(6,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
                                    
        /* Insertion des elements */
        F=fopen(l,"r");
	while(fscanf(F,"%s %s %s %s %d %s \n",TR.identifiant_tr,TR.type_tr,TR.sexe_tr,TR.d_n_tr,&TR.poids_tr,TR.budget_tr)!=EOF)
        {
	if(strcmp(type_tr,TR.type_tr)==0)
	 {   nb++;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(store, &iter);
         /* Mise a jour des donnees */
         gtk_list_store_set(store, &iter,
                            0,TR.identifiant_tr,
                            1,TR.type_tr,
                            2,TR.sexe_tr,
                            3,TR.d_n_tr,
                            4,TR.poids_tr,
                            5,TR.budget_tr,
                            -1);
	 }
	}
        fclose(F);
	if(store==NULL)
	{
        if(j==0)
	{
	/* Creation de la 1ere colonne */
	renderer= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Identifiant ",
                                                            renderer,
                                                            "text", 0,
                                                            NULL);

        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	/* Creation de la 2eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Type ",
                                                            renderer,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 3eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Sexe ",
                                                            renderer,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 4eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Date de naissance ",
                                                            renderer,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 5eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Poids ",
                                                            renderer,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 6eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" Budget ",
                                                            renderer,
                                                            "text", 5,
                                                            NULL);
	/* Ajouter la 6emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	j++;
	}
	}	
 	gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store));
        return nb;
   }

/********************************************** Gestion de facture ******************************/

void Ajouter_Facture(Facture FC)
 {
   FILE *FA;
   FA=fopen("Facture.txt","a+");
  if(FA!=NULL)
    {
   fprintf(FA,"%s %s %s %s %d %s %s \n",FC.reference_fc,FC.nomprenom_fc,FC.numcarte_fc,FC.produit_fc,FC.quantite_fc,FC.montant_fc,FC.date_fc);
   fclose(FA);
    }
  } 

 int Exist_Facture(char *reference_fc)
 {
   FILE*FA=NULL;
   Facture FC;
   FA=fopen("Facture.txt","r");
   while(fscanf(FA,"%s %s %s %s %d %s %s \n",FC.reference_fc,FC.nomprenom_fc,FC.numcarte_fc,FC.produit_fc,&FC.quantite_fc,FC.montant_fc,FC.date_fc)!=EOF)
   {
   if(strcmp(FC.reference_fc,reference_fc)==0)return 1;
   }
   fclose(FA);
   return 0;
  }

void Supprimer_Facture(char* reference_fc)
 {
     Facture FC2;	 
    FILE *FA,*FichA;
    FA = fopen("Facture.txt","r");
    FichA = fopen("TmpFacture.txt","w");
    if(FA ==NULL || FichA==NULL)
     {
	return;
     }
    else{
    while(fscanf(FA,"%s %s %s %s %d %s %s \n",FC2.reference_fc,FC2.nomprenom_fc,FC2.numcarte_fc,FC2.produit_fc,&FC2.quantite_fc,FC2.montant_fc,FC2.date_fc)!=EOF)
     { 
     if(strcmp(reference_fc,FC2.reference_fc)!=0)
       { 
     fprintf(FichA,"%s %s %s %s %d %s %s \n",FC2.reference_fc,FC2.nomprenom_fc,FC2.numcarte_fc,FC2.produit_fc,FC2.quantite_fc,FC2.montant_fc,FC2.date_fc); 
       }
     }
    fclose(FA);
    fclose(FichA);
    remove("Facture.txt");
    rename("TmpFacture.txt","Facture.txt");
        }
 }

/****************************************** Treeview Facture ********************************/


int Afficher_Facture(GtkWidget *liste, char *l)
  {



	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de 		chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son 		attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de 		treeview
	GtkListStore  *store;    //l'enregistrement de treeview

	 char reference_fc[20];
	 char nomprenom_fc[20];
	 char numcarte_fc[20];
	 char produit_fc[20];
	 int quantite_fc;
	 char montant_fc[20]; 
	 char date_fc[20];
int n=0;

	
	 store=NULL;
	 FILE *FA;

	store=gtk_tree_view_get_model(liste);//va prendre comme variable de la liste
	if(store==NULL)
	{
	
	renderer = gtk_cell_renderer_text_new (); //cellule contenant du texte
	column = gtk_tree_view_column_new_with_attributes("   Référence  ", renderer,"text",0,NULL);//creation d'une 		colonne avec du texte
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);//associer la colonne à l'afficher (GtkTreeView);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Nom et prénom   ",  renderer,"text",1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Num carte id   ", renderer,"text",2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Produits   ", renderer,"text",3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Quantité   ", renderer,"text",4,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Montant   ", renderer,"text",5,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("   Date d'ajouté   ", renderer,"text",6,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}

	//lA liste contient 7 colonnes de type chaine de caracteres
	store=gtk_list_store_new(7, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING,G_TYPE_STRING);
	FA=fopen(l,"r");
	if(FA==NULL)
	{
	return;
	}
	else
	{ Facture FC;
   	FA=fopen(l,"a+");
   	while(fscanf(FA,"%s %s %s %s %d %s %s \n",reference_fc,nomprenom_fc,numcarte_fc,produit_fc,&quantite_fc,montant_fc,date_fc)!=EOF)
	{   n++;

        	
	gtk_list_store_append (store, &iter);//variable intermediaire store
	gtk_list_store_set (store, &iter,0,reference_fc,1,nomprenom_fc,2,numcarte_fc,3,produit_fc,4,quantite_fc,5,
	montant_fc,6,date_fc, -1);//correspondre chaque champ a mon variable
	}
	fclose(FA);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));//
	g_object_unref (store);
	}
return n;

   }
int Chercher_Facture(GtkWidget *liste, char *l,char* numcarte_fc)
   {

	GtkCellRenderer *renderer;  //envoyer la saisir de l'utilisateur de chaque champ 
	GtkTreeViewColumn *column;//correspendre le contenue du champ a son attribue de la liste
	GtkTreeIter   iter;    //itterateur sur l'ensemble des elements de treeview
	GtkListStore  *store;
	FILE *FA;
 	int nb=0;
	int i;
	Facture FC;
     store=NULL;

        
	/* Creation du modele */
       store = gtk_list_store_new(7,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING,G_TYPE_STRING);
                                    
        /* Insertion des elements */
        FA=fopen(l,"r");
	while(fscanf(FA,"%s %s %s %s %d %s %s \n",FC.reference_fc,FC.nomprenom_fc,FC.numcarte_fc,FC.produit_fc,&FC.quantite_fc,FC.montant_fc,FC.date_fc)!=EOF)
        {
	if(strcmp(numcarte_fc,FC.numcarte_fc)==0)
	 {   nb++;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(store, &iter);
         /* Mise a jour des donnees */
         gtk_list_store_set(store, &iter,
                            0,FC.reference_fc,
                            1,FC.nomprenom_fc,
                            2,FC.numcarte_fc,
                            3,FC.produit_fc,
                            4,FC.quantite_fc,
                            5,FC.montant_fc,
			    6,FC.date_fc,
                            -1);
	 }
	}
        fclose(FA);
	if(store==NULL)
	{
        if(i==0)
	{
	/* Creation de la 1ere colonne */
	renderer= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Référence  ",
                                                            renderer,
                                                            "text", 0,
                                                            NULL);

        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	/* Creation de la 2eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Nom et prénom   ",
                                                            renderer,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 3eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Num carte id   ",
                                                            renderer,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 4eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Produits   ",
                                                            renderer,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 5eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Quantité   ",
                                                            renderer,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 6eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Montant   ",
                                                            renderer,
                                                            "text", 5,
                                                            NULL);
	/* Ajouter la 6emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	/* Creation de la 7eme colonne */
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("   Date d'ajoute   ",
                                                            renderer,
                                                            "text", 6,
                                                            NULL);
	/* Ajouter la 7emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	i++;
	}
	}	
 	gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store));
        return nb;
   }





