#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "CRUD.h"



///////************* Gestion de Troupeaux ********************///////
void
on_button_tr_ajouter_clicked           (GtkWidget         *gest_trou,
                                        gpointer         user_data)
{

	Troupeaux TR;
	GtkWidget *input_id_tr,*input_poid_tr,*input_budg_tr;
  	GtkWidget *combo1_tr;
 	GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);
	GtkWidget *pInfo;
  	GtkWidget *pWindow;
        GSList *pList;
        const gchar *sLabel;

 	GtkWidget* radio1_tr; 
	GtkWidget* radio2_tr;
	GtkWidget *labelid_tr;
	GtkWidget *labelbd_tr;
	GtkWidget *labelsucces_tr;
	GtkWidget *labelCombo_tr;
	GtkWidget *labelExist_tr;

	GtkWidget *calendr_tr;
	int jr_tr,m_tr,a_tr;
	int b=1;

	FILE*F=NULL;



	labelid_tr=lookup_widget(gest_trou,"label_saisir_id_TR");
	labelbd_tr=lookup_widget(gest_trou,"label_bd_TR");
	labelsucces_tr=lookup_widget(gest_trou,"label_succes_TR");
	labelCombo_tr=lookup_widget(gest_trou,"label_tp_TR");
	labelExist_tr=lookup_widget(gest_trou,"label_exist_TR");
           

	input_id_tr=lookup_widget(gest_trou,"identifiant_tr");
	combo1_tr=lookup_widget(gest_trou,"combobox1_tr");
	calendr_tr=lookup_widget(gest_trou,"calendar1_tr_r");

	input_poid_tr=lookup_widget(gest_trou,"poid_tr");
	input_budg_tr=lookup_widget(gest_trou,"budget_tr");
	radio1_tr=lookup_widget(GTK_WIDGET(gest_trou),"radio_tr_f");
	radio2_tr=lookup_widget(GTK_WIDGET(gest_trou),"radio_tr_h");

	gtk_widget_hide (labelsucces_tr);


	strcpy(TR.identifiant_tr,gtk_entry_get_text(GTK_ENTRY(input_id_tr)));
	strcpy(TR.budget_tr,gtk_entry_get_text(GTK_ENTRY(input_budg_tr)));
	if(strcmp(TR.budget_tr,"")==0)

	{
		        gtk_widget_show (labelbd_tr);
	b=0;

	}else
	{
		   gtk_widget_hide (labelbd_tr);
	}

	if(strcmp(TR.identifiant_tr,"")==0){
		        gtk_widget_show (labelid_tr);
	b=0;

	}else
	{
		   gtk_widget_hide (labelid_tr);
	}




	if(gtk_combo_box_get_active (GTK_COMBO_BOX(combo1_tr))==-1)
	{
		        gtk_widget_show (labelCombo_tr);
	b=0;
	}
	else{

		   gtk_widget_hide (labelCombo_tr);
	}

	if(b==1)
      {
	  /* Récupération de la liste des boutons */
	    pList = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio1_tr));
	 



	    /* Parcours de la liste */
	    while(pList)
	    {
		/* Le bouton est-il sélectionné */
		if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(pList->data)))
		{
		    /* OUI -> on copie le label du bouton */
		    sLabel = gtk_button_get_label(GTK_BUTTON(pList->data));
		    /* On met la liste a NULL pour sortir de la boucle */
		    pList = NULL;
		}
		else
		{
		    /* NON -> on passe au bouton suivant */
		    pList = g_slist_next(pList);
		}
	    }

	strcpy(TR.type_tr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1_tr)));

	gtk_calendar_get_date (GTK_CALENDAR(calendr_tr),
                       &a_tr,
                       &m_tr,
                       &jr_tr);

	TR.poids_tr=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input_poid_tr));

  

	if(Exist_Troupeau(TR.identifiant_tr)==1) {
		   gtk_widget_show (labelExist_tr);

	}
	else{
		   gtk_widget_hide (labelExist_tr);

				
	F=fopen("Troupeau.txt","a+");
	fprintf(F,"%s %s %s %d/%d/%d %d %s \n",TR.identifiant_tr,TR.type_tr,sLabel,jr_tr,m_tr+1,a_tr,TR.poids_tr,TR.budget_tr);
	fclose(F);	

                   gtk_widget_show (labelsucces_tr);

	GtkWidget *p;
	p=lookup_widget(gest_trou,"treeview1_tr");
	Afficher_Troupeau(p,"Troupeau.txt");
	// Ajouter_Troupeau(TR);
	    } 
   }
}
void
on_treeview1_tr_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar* identifiant_tr;
	gchar* type_tr;
	gchar* sexe_tr;
	GtkTreeModel     *model;

	gchar* d_n_tr;
	gint poids_tr;
	gchar* budget_tr;
	Troupeaux TR;
	int x=0;
		 
	GtkWidget *p=lookup_widget(treeview,"treeview1_tr");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
	model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model, &iter,path)){
	//obtention des valeurs de la ligne selectionnée
	gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0,&identifiant_tr,1,&type_tr,2,&sexe_tr,3,&d_n_tr,4,
	&poids_tr,5,&budget_tr, -1);//recuperer les informations de la ligne selectionneé

        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_sx")),sexe_tr);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_dn")),d_n_tr);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_bd")),budget_tr);
        gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(treeview,"spinbutton_af_po")),poids_tr);

        if(strcmp(type_tr,"Veau")==0) x=0;
        if(strcmp(type_tr,"Brebi")==0) x=1;

        gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(treeview,"combobox2_tr_tp")),x);
	GtkWidget* msg=lookup_widget(treeview,"label31_id_tr_r");
        gtk_label_set_text(GTK_LABEL(msg),identifiant_tr);
	       
}



}


void
on_button_modifiet_tr_clicked          (GtkWidget        *gest_trou,
                                        gpointer         user_data)
{
	Troupeaux TR;
	FILE*F=NULL;
        strcpy(TR.identifiant_tr,gtk_label_get_text(GTK_LABEL(lookup_widget(gest_trou,"label31_id_tr_r"))));
        strcpy(TR.type_tr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gest_trou,"combobox2_tr_tp"))));
        strcpy(TR.sexe_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_sx"))));
        strcpy(TR.d_n_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_dn"))));
        TR.poids_tr =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gest_trou,"spinbutton_af_po")));
        strcpy(TR.budget_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_bd"))));	

	Supprimer_Troupeau(TR.identifiant_tr);
	Ajouter_Troupeau(TR);

       	Afficher_Troupeau(lookup_widget(gest_trou,"treeview1_tr"),"Troupeau.txt");
 	GtkWidget* msg_modif_tr=lookup_widget(gest_trou,"label_suc_modif_tr");
        gtk_widget_show(msg_modif_tr);

}


void
on_supprime_TR_clicked                 (GtkWidget        *gest_trou,
                                        gpointer         user_data)
{

        Troupeaux TR2;
        GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label_tr_sp;
        gchar* identifiant_tr;

        label_tr_sp=lookup_widget(gest_trou,"label_sel_tr");
        p=lookup_widget(gest_trou,"treeview1_tr");

        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
	   gtk_tree_model_get (model,&iter,0,&identifiant_tr,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           Supprimer_Troupeau(identifiant_tr);// supprimer la ligne du fichier
	   gtk_widget_hide (label_tr_sp);
	}else{
                gtk_widget_show (label_tr_sp);

	     }

}


void
on_button_chercher_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{

	GtkWidget *p1;
	GtkWidget *entry_type;
	GtkWidget *labeltype;
	GtkWidget *nbResultat;
	GtkWidget *message;

	char type_tr[30];
	char chnb[30];
	int b=0,nb;

	entry_type=lookup_widget(gest_trou,"entry_chr_tr");
	labeltype=lookup_widget(gest_trou,"label42_id_tr");
	p1=lookup_widget(gest_trou,"treeview2_tr");
	strcpy(type_tr,gtk_entry_get_text(GTK_ENTRY(entry_type)));

	if(strcmp(type_tr,"")==0)
	{
	  gtk_widget_show (labeltype);b=0;
	}
	else{
	b=1;
	gtk_widget_hide (labeltype);
	    }

	if(b==0){return;}else{

	nb=Chercher_Troupeau(p1,"Troupeau.txt",type_tr);//type entry ecrie par lutilisateur
	/* afficher le nombre de resultats obtenue par la recherche */
	sprintf(chnb,"%d",nb);
	nbResultat=lookup_widget(gest_trou,"label44_tr");
	message=lookup_widget(gest_trou,"label43_tr");
	gtk_label_set_text(GTK_LABEL(nbResultat),chnb);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbResultat);
	gtk_widget_show (message);

	                     }




}


void
on_AcceuilGestionTroupeau_clicked      (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{


	GtkWidget *Acceuil;
	GtkWidget *Gestion_Troupeau;
	Troupeaux TR;
	Acceuil=lookup_widget(gest_trou,"Acceuil");
	gtk_widget_hide(Acceuil);
	Gestion_Troupeau = create_Gestion_Troupeau ();
	gtk_widget_show(Gestion_Troupeau);

}


void
on_button_Actualise_Troupeau_clicked   (GtkWidget      *gest_trou,
                                        gpointer         user_data)
{
	GtkWidget *p;
	GtkWidget *p1;
	int nt;
	GtkWidget *nbt_tr;
	char ch_tr[30];
	FILE*F=NULL;
	Troupeaux TR;
	nbt_tr=lookup_widget(gest_trou,"labelnb_tr");
	p=lookup_widget(gest_trou,"treeview1_tr");
	p1=lookup_widget(gest_trou,"treeview2_tr");

	nt=Afficher_Troupeau(p,"Troupeau.txt");
	Afficher_Troupeau(p1,"Troupeau.txt");
	sprintf(ch_tr,"%d",nt);
	gtk_label_set_text(GTK_LABEL(nbt_tr),ch_tr);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbt_tr);

}


void
on_button_ret_tr_clicked               (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{

	GtkWidget *Acceuil;
	GtkWidget *Gestion_Troupeau;

	Troupeaux TR;
	Gestion_Troupeau=lookup_widget(gest_trou,"Gestion_Troupeau");
	gtk_widget_hide (Gestion_Troupeau);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);

}


///////************* Gestion de Facture ********************///////

int choix[4]={0,0,0,0};


void
on_Ajouter_fc_clicked                  (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{

	Facture FC;
	int jr_fc,m_fc,a_fc;
	FILE*FA=NULL;
	char resul[100]="";
	int a=1;
	GtkWidget *ref_fc,*nom_fc,*carteid_fc,*qant_fc,*mont_fc,*datajout_fc;

	GtkWidget *labelsucces_fc,*labelexiste_fc,*labelref_fc,*labelnom_fc,*labelnum_fc,*labelprod_fc,*labelmont_fc;

	labelsucces_fc=lookup_widget(gest_fact,"label113_fc");
	labelexiste_fc=lookup_widget(gest_fact,"label114_fc");
	labelref_fc=lookup_widget(gest_fact,"label108_fc");
	labelnom_fc=lookup_widget(gest_fact,"label109_fc");
	labelnum_fc=lookup_widget(gest_fact,"label110_fc");
	labelprod_fc=lookup_widget(gest_fact,"label112_fc");
	labelmont_fc=lookup_widget(gest_fact,"label111_fc");


		gtk_widget_hide (labelsucces_fc);

	ref_fc=lookup_widget(gest_fact,"ref_fc_r");
	nom_fc=lookup_widget(gest_fact,"n_p_fc_r");
	carteid_fc=lookup_widget(gest_fact,"n_c_i_fc_r");
	qant_fc=lookup_widget(gest_fact,"spinbutton_fc_r");
	mont_fc=lookup_widget(gest_fact,"mo_fc_r");
	datajout_fc=lookup_widget(gest_fact,"calendar_fc_r");

	strcpy(FC.reference_fc,gtk_entry_get_text(GTK_ENTRY(ref_fc)));
	strcpy(FC.nomprenom_fc,gtk_entry_get_text(GTK_ENTRY(nom_fc)));
	strcpy(FC.numcarte_fc,gtk_entry_get_text(GTK_ENTRY(carteid_fc)));
	FC.quantite_fc=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (qant_fc));
	strcpy(FC.montant_fc,gtk_entry_get_text(GTK_ENTRY(mont_fc)));

	if(strcmp(FC.reference_fc,"")==0)

	{
		        gtk_widget_show (labelref_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelref_fc);
	}

	if(strcmp(FC.nomprenom_fc,"")==0)

	{
		        gtk_widget_show (labelnom_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelnom_fc);
	}

	if(strcmp(FC.numcarte_fc,"")==0)

	{
		        gtk_widget_show (labelnum_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelnum_fc);
	}

	if(strcmp(FC.montant_fc,"")==0)

	{
		        gtk_widget_show (labelmont_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelmont_fc);
	}

	if(a==1)
       {

	gtk_calendar_get_date (GTK_CALENDAR(datajout_fc),
                       &a_fc,
                       &m_fc,
                       &jr_fc);
	
	if(choix[0]==1)strcat(resul,"*Veau*");
	if(choix[1]==1)strcat(resul,"*Brebi*");
	if(choix[2]==1)strcat(resul,"*Arboriculture*");
	if(choix[3]==1)strcat(resul,"*serriculture*");
	
	if(Exist_Facture(FC.reference_fc)==1) {
		   gtk_widget_show (labelexiste_fc);

	}
	else{
		   gtk_widget_hide (labelexiste_fc);

	FA=fopen("Facture.txt","a+");
	fprintf(FA,"  %s   %s   %s   %s   %d   %s   %d/%d/%d \n",FC.reference_fc,FC.nomprenom_fc,FC.numcarte_fc,resul,FC.quantite_fc,FC.montant_fc,jr_fc,m_fc+1,a_fc);
	fclose(FA);
	strcpy(resul,"");
        gtk_widget_show (labelsucces_fc);
	GtkWidget *p;
	p=lookup_widget(gest_fact,"treeview1_fc");
	Afficher_Facture(p,"Facture.txt");

}

}
}


void
on_treeview1_fc_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* reference_fc;
	gchar* nomprenom_fc;
	gchar* numcarte_fc;
	GtkTreeModel     *model;

	gchar* produit_fc;
	gint quantite_fc;
	gchar* montant_fc;
	gchar* date_fc;
	Facture FC;
	int x=0;
		 
	GtkWidget *p=lookup_widget(treeview,"treeview1_fc");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
	model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model, &iter,path)){
	//obtention des valeurs de la ligne selectionnée
	gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0,&reference_fc,1,&nomprenom_fc,2,&numcarte_fc,3,&produit_fc,4,
	&quantite_fc,5,&montant_fc,6,&date_fc, -1);//recuperer les informations de la ligne selectionneé

        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"n_p_modif_fc")),nomprenom_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"n_c_i_modif_fc")),numcarte_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"p_modif_fc")),produit_fc);
        gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(treeview,"spinbutton_modif_fc")),quantite_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"mo_modif_fc")),montant_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"da_modif_fc")),date_fc);

	GtkWidget* msg=lookup_widget(treeview,"label103_modif_fc");
        gtk_label_set_text(GTK_LABEL(msg),reference_fc);
	       
}
}


void
on_Modifier_fc_clicked                 (GtkWidget      *gest_fact,
                                        gpointer         user_data)
{
	Facture FC;
	FILE*FA=NULL;
        strcpy(FC.reference_fc,gtk_label_get_text(GTK_LABEL(lookup_widget(gest_fact,"label103_modif_fc"))));
        strcpy(FC.nomprenom_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"n_p_modif_fc"))));
        strcpy(FC.numcarte_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"n_c_i_modif_fc"))));
        strcpy(FC.produit_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"p_modif_fc"))));
        FC.quantite_fc =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gest_fact,"spinbutton_modif_fc")));
        strcpy(FC.montant_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"mo_modif_fc"))));
        strcpy(FC.date_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"da_modif_fc"))));		
	
	Supprimer_Facture(FC.reference_fc);
	Ajouter_Facture(FC);

       	Afficher_Facture(lookup_widget(gest_fact,"treeview1_fc"),"Facture.txt");
 	GtkWidget* msg_modif_fc=lookup_widget(gest_fact,"label106_fc");
        gtk_widget_show(msg_modif_fc);
}


void
on_checkbutton1_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(togglebutton))
{choix[0]=1;}else{choix[0]=0;}



}


void
on_checkbutton2_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choix[1]=1;}else{choix[1]=0;}

}


void
on_checkbutton3_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choix[2]=1;}else{choix[2]=0;}

}


void
on_checkbutton4_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(togglebutton))
{choix[3]=1;}else{choix[3]=0;}

}


void
on_AcceuilGestionFacture_clicked       (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_Facture;
	Acceuil=lookup_widget(gest_fact,"Acceuil");
	gtk_widget_hide(Acceuil);
	Gestion_Facture= create_Gestion_Facture ();
	gtk_widget_show(Gestion_Facture);

}


void
on_Actualiser_fc_clicked               (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{

	GtkWidget *p;
	GtkWidget *p1;
	int n;
	GtkWidget *nbA_fc;
	char ch_fc[30];
	
	FILE*FA=NULL;

	nbA_fc=lookup_widget(gest_fact,"labelnb_fc");
	p=lookup_widget(gest_fact,"treeview1_fc");
	p1=lookup_widget(gest_fact,"treeview2_fc");

	n=Afficher_Facture(p,"Facture.txt");
	Afficher_Facture(p1,"Facture.txt");
	sprintf(ch_fc,"%d",n);
	gtk_label_set_text(GTK_LABEL(nbA_fc),ch_fc);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbA_fc);
}


void
on_Supp_fc_clicked                     (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{
	Facture FC;
        GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label_fc_sp;
        gchar* reference_fc;

        label_fc_sp=lookup_widget(gest_fact,"label107_fc");
        p=lookup_widget(gest_fact,"treeview1_fc");

        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
	   gtk_tree_model_get (model,&iter,0,&reference_fc,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           Supprimer_Facture(reference_fc);// supprimer la ligne du fichier
	   gtk_widget_hide (label_fc_sp);
	}else{
                gtk_widget_show (label_fc_sp);

	     }


}


void
on_Chercher_fc_clicked                 (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *p1;
	GtkWidget *num_fc;
	GtkWidget *labelnum_fc;
	GtkWidget *nbResultat_fc;
	GtkWidget *message_fc;

	char numcarte_fc[30];
	char chnb_fc[30];
	int a=0,nb;

	num_fc=lookup_widget(gest_fact,"nym_rech_fc");
	labelnum_fc=lookup_widget(gest_fact,"label105_fc");
	p1=lookup_widget(gest_fact,"treeview2_fc");
	strcpy(numcarte_fc,gtk_entry_get_text(GTK_ENTRY(num_fc)));

	if(strcmp(numcarte_fc,"")==0)
	{
	  gtk_widget_show (labelnum_fc);a=0;
	}
	else{
	a=1;
	gtk_widget_hide (labelnum_fc);
	    }

	if(a==0){return;}else{

	nb=Chercher_Facture(p1,"Facture.txt",numcarte_fc);//type entry ecrie par lutilisateur
	/* afficher le nombre de resultats obtenue par la recherche */
	sprintf(chnb_fc,"%d",nb);
	nbResultat_fc=lookup_widget(gest_fact,"label104_fc");
	message_fc=lookup_widget(gest_fact,"label103_fc");
	gtk_label_set_text(GTK_LABEL(nbResultat_fc),chnb_fc);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbResultat_fc);
	gtk_widget_show (message_fc);

	                     }

}


void
on_Retour_fc_clicked                   (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_Facture;


	Gestion_Facture=lookup_widget(gest_fact,"Gestion_Facture");
	gtk_widget_hide (Gestion_Facture);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);

}


