
#include <gtk/gtk.h>


  typedef struct{
    char identifiant_tr[20];
    char type_tr[20];
    char sexe_tr[20];
    char d_n_tr[20];
    int poids_tr;
    char budget_tr[20];
  }Troupeaux;

  typedef struct{
    char reference_fc[20];
    char nomprenom_fc[20];
    char numcarte_fc[20];
    char produit_fc[20];
    int quantite_fc;
    char montant_fc[20]; 
    char date_fc[20];
  }Facture;


/***************** Gestion de troupeaux *****************/

  void Ajouter_Troupeau(Troupeaux TR);  
  void Supprimer_Troupeau(char* identifiant_tr);
  int Exist_Troupeau(char *identifiant_tr);
  int Afficher_Troupeau(GtkWidget *liste, char *l);
  int Chercher_Troupeau(GtkWidget *liste, char *l,char* type_tr);

/***************** Gestion de facture *****************/

  void Ajouter_Facture(Facture FC);  
  void Supprimer_Facture(char* reference_fc);
  int Exist_Facture(char *reference_fc);
  int Afficher_Facture(GtkWidget *liste, char *l);
  int Chercher_Facture(GtkWidget *liste, char *l,char* numcarte_fc);

