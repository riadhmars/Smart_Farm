#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "CRUD.h"
#include "capteur.h"
#include "equipements.h"
#include "client.h"
#include "commande.h"
#include "travaill.h"



///////************* Gestion de Troupeaux ********************///////
void
on_button_tr_ajouter_clicked           (GtkWidget         *gest_trou,
                                        gpointer         user_data)
{

	Troupeaux TR;
	GtkWidget *input_id_tr,*input_poid_tr,*input_budg_tr;
  	GtkWidget *combo1_tr;
 	GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);
	GtkWidget *pInfo;
  	GtkWidget *pWindow;
        GSList *pList;
        const gchar *sLabel;

 	GtkWidget* radio1_tr; 
	GtkWidget* radio2_tr;
	GtkWidget *labelid_tr;
	GtkWidget *labelbd_tr;
	GtkWidget *labelsucces_tr;
	GtkWidget *labelCombo_tr;
	GtkWidget *labelExist_tr;

	GtkWidget *calendr_tr;
	int jr_tr,m_tr,a_tr;
	int b=1;

	FILE*F=NULL;



	labelid_tr=lookup_widget(gest_trou,"label_saisir_id_TR");
	labelbd_tr=lookup_widget(gest_trou,"label_bd_TR");
	labelsucces_tr=lookup_widget(gest_trou,"label_succes_TR");
	labelCombo_tr=lookup_widget(gest_trou,"label_tp_TR");
	labelExist_tr=lookup_widget(gest_trou,"label_exist_TR");
           

	input_id_tr=lookup_widget(gest_trou,"identifiant_tr");
	combo1_tr=lookup_widget(gest_trou,"combobox1_tr");
	calendr_tr=lookup_widget(gest_trou,"calendar1_tr_r");

	input_poid_tr=lookup_widget(gest_trou,"poid_tr");
	input_budg_tr=lookup_widget(gest_trou,"budget_tr");
	radio1_tr=lookup_widget(GTK_WIDGET(gest_trou),"radio_tr_f");
	radio2_tr=lookup_widget(GTK_WIDGET(gest_trou),"radio_tr_h");

	gtk_widget_hide (labelsucces_tr);


	strcpy(TR.identifiant_tr,gtk_entry_get_text(GTK_ENTRY(input_id_tr)));
	strcpy(TR.budget_tr,gtk_entry_get_text(GTK_ENTRY(input_budg_tr)));
	if(strcmp(TR.budget_tr,"")==0)

	{
		        gtk_widget_show (labelbd_tr);
	b=0;

	}else
	{
		   gtk_widget_hide (labelbd_tr);
	}

	if(strcmp(TR.identifiant_tr,"")==0){
		        gtk_widget_show (labelid_tr);
	b=0;

	}else
	{
		   gtk_widget_hide (labelid_tr);
	}




	if(gtk_combo_box_get_active (GTK_COMBO_BOX(combo1_tr))==-1)
	{
		        gtk_widget_show (labelCombo_tr);
	b=0;
	}
	else{

		   gtk_widget_hide (labelCombo_tr);
	}

	if(b==1)
      {
	  /* Récupération de la liste des boutons */
	    pList = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio1_tr));
	 



	    /* Parcours de la liste */
	    while(pList)
	    {
		/* Le bouton est-il sélectionné */
		if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(pList->data)))
		{
		    /* OUI -> on copie le label du bouton */
		    sLabel = gtk_button_get_label(GTK_BUTTON(pList->data));
		    /* On met la liste a NULL pour sortir de la boucle */
		    pList = NULL;
		}
		else
		{
		    /* NON -> on passe au bouton suivant */
		    pList = g_slist_next(pList);
		}
	    }

	strcpy(TR.type_tr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1_tr)));

	gtk_calendar_get_date (GTK_CALENDAR(calendr_tr),
                       &a_tr,
                       &m_tr,
                       &jr_tr);

	TR.poids_tr=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input_poid_tr));

  

	if(Exist_Troupeau(TR.identifiant_tr)==1) {
		   gtk_widget_show (labelExist_tr);

	}
	else{
		   gtk_widget_hide (labelExist_tr);

				
	F=fopen("Troupeau.txt","a+");
	fprintf(F,"%s %s %s %d/%d/%d %d %s \n",TR.identifiant_tr,TR.type_tr,sLabel,jr_tr,m_tr+1,a_tr,TR.poids_tr,TR.budget_tr);
	fclose(F);	

                   gtk_widget_show (labelsucces_tr);

	GtkWidget *p;
	p=lookup_widget(gest_trou,"treeview1_tr");
	Afficher_Troupeau(p,"Troupeau.txt");
	// Ajouter_Troupeau(TR);
	    } 
   }
}
void
on_treeview1_tr_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar* identifiant_tr;
	gchar* type_tr;
	gchar* sexe_tr;
	GtkTreeModel     *model;

	gchar* d_n_tr;
	gint poids_tr;
	gchar* budget_tr;
	Troupeaux TR;
	int x=0;
		 
	GtkWidget *p=lookup_widget(treeview,"treeview1_tr");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
	model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model, &iter,path)){
	//obtention des valeurs de la ligne selectionnée
	gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0,&identifiant_tr,1,&type_tr,2,&sexe_tr,3,&d_n_tr,4,
	&poids_tr,5,&budget_tr, -1);//recuperer les informations de la ligne selectionneé

        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_sx")),sexe_tr);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_dn")),d_n_tr);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"entry_af_bd")),budget_tr);
        gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(treeview,"spinbutton_af_po")),poids_tr);

        if(strcmp(type_tr,"Veau")==0) x=0;
        if(strcmp(type_tr,"Brebi")==0) x=1;

        gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(treeview,"combobox2_tr_tp")),x);
	GtkWidget* msg=lookup_widget(treeview,"label31_id_tr_r");
        gtk_label_set_text(GTK_LABEL(msg),identifiant_tr);
	       
}



}


void
on_button_modifiet_tr_clicked          (GtkWidget        *gest_trou,
                                        gpointer         user_data)
{
	Troupeaux TR;
	FILE*F=NULL;
        strcpy(TR.identifiant_tr,gtk_label_get_text(GTK_LABEL(lookup_widget(gest_trou,"label31_id_tr_r"))));
        strcpy(TR.type_tr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gest_trou,"combobox2_tr_tp"))));
        strcpy(TR.sexe_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_sx"))));
        strcpy(TR.d_n_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_dn"))));
        TR.poids_tr =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gest_trou,"spinbutton_af_po")));
        strcpy(TR.budget_tr,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_trou,"entry_af_bd"))));	

	Supprimer_Troupeau(TR.identifiant_tr);
	Ajouter_Troupeau(TR);

       	Afficher_Troupeau(lookup_widget(gest_trou,"treeview1_tr"),"Troupeau.txt");
 	GtkWidget* msg_modif_tr=lookup_widget(gest_trou,"label_suc_modif_tr");
        gtk_widget_show(msg_modif_tr);

}


void
on_supprime_TR_clicked                 (GtkWidget        *gest_trou,
                                        gpointer         user_data)
{

        Troupeaux TR2;
        GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label_tr_sp;
        gchar* identifiant_tr;

        label_tr_sp=lookup_widget(gest_trou,"label_sel_tr");
        p=lookup_widget(gest_trou,"treeview1_tr");

        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
	   gtk_tree_model_get (model,&iter,0,&identifiant_tr,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           Supprimer_Troupeau(identifiant_tr);// supprimer la ligne du fichier
	   gtk_widget_hide (label_tr_sp);
	}else{
                gtk_widget_show (label_tr_sp);

	     }

}


void
on_button_chercher_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{

	GtkWidget *p1;
	GtkWidget *entry_type;
	GtkWidget *labeltype;
	GtkWidget *nbResultat;
	GtkWidget *message;

	char type_tr[30];
	char chnb[30];
	int b=0,nb;

	entry_type=lookup_widget(gest_trou,"entry_chr_tr");
	labeltype=lookup_widget(gest_trou,"label42_id_tr");
	p1=lookup_widget(gest_trou,"treeview2_tr");
	strcpy(type_tr,gtk_entry_get_text(GTK_ENTRY(entry_type)));

	if(strcmp(type_tr,"")==0)
	{
	  gtk_widget_show (labeltype);b=0;
	}
	else{
	b=1;
	gtk_widget_hide (labeltype);
	    }

	if(b==0){return;}else{

	nb=Chercher_Troupeau(p1,"Troupeau.txt",type_tr);//type entry ecrie par lutilisateur
	/* afficher le nombre de resultats obtenue par la recherche */
	sprintf(chnb,"%d",nb);
	nbResultat=lookup_widget(gest_trou,"label44_tr");
	message=lookup_widget(gest_trou,"label43_tr");
	gtk_label_set_text(GTK_LABEL(nbResultat),chnb);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbResultat);
	gtk_widget_show (message);

	                     }




}


void
on_AcceuilGestionTroupeau_clicked      (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{


	GtkWidget *Acceuil;
	GtkWidget *Gestion_Troupeau;
	Troupeaux TR;
	Acceuil=lookup_widget(gest_trou,"Acceuil");
	gtk_widget_hide(Acceuil);
	Gestion_Troupeau = create_Gestion_Troupeau ();
	gtk_widget_show(Gestion_Troupeau);

}


void
on_button_Actualise_Troupeau_clicked   (GtkWidget      *gest_trou,
                                        gpointer         user_data)
{
	GtkWidget *p;
	GtkWidget *p1;
	int nt;
	GtkWidget *nbt_tr;
	char ch_tr[30];
	FILE*F=NULL;
	Troupeaux TR;
	nbt_tr=lookup_widget(gest_trou,"labelnb_tr");
	p=lookup_widget(gest_trou,"treeview1_tr");
	p1=lookup_widget(gest_trou,"treeview2_tr");

	nt=Afficher_Troupeau(p,"Troupeau.txt");
	Afficher_Troupeau(p1,"Troupeau.txt");
	sprintf(ch_tr,"%d",nt);
	gtk_label_set_text(GTK_LABEL(nbt_tr),ch_tr);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbt_tr);

}


void
on_button_ret_tr_clicked               (GtkWidget       *gest_trou,
                                        gpointer         user_data)
{

	GtkWidget *Acceuil;
	GtkWidget *Gestion_Troupeau;

	Troupeaux TR;
	Gestion_Troupeau=lookup_widget(gest_trou,"Gestion_Troupeau");
	gtk_widget_hide (Gestion_Troupeau);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);

}


///////************* Gestion de Facture ********************///////

int choix[4]={0,0,0,0};


void
on_Ajouter_fc_clicked                  (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{

	Facture FC;
	int jr_fc,m_fc,a_fc;
	FILE*FA=NULL;
	char resul[100]="";
	int a=1;
	GtkWidget *ref_fc,*nom_fc,*carteid_fc,*qant_fc,*mont_fc,*datajout_fc;

	GtkWidget *labelsucces_fc,*labelexiste_fc,*labelref_fc,*labelnom_fc,*labelnum_fc,*labelprod_fc,*labelmont_fc;

	labelsucces_fc=lookup_widget(gest_fact,"label113_fc");
	labelexiste_fc=lookup_widget(gest_fact,"label114_fc");
	labelref_fc=lookup_widget(gest_fact,"label108_fc");
	labelnom_fc=lookup_widget(gest_fact,"label109_fc");
	labelnum_fc=lookup_widget(gest_fact,"label110_fc");
	labelprod_fc=lookup_widget(gest_fact,"label112_fc");
	labelmont_fc=lookup_widget(gest_fact,"label111_fc");


		gtk_widget_hide (labelsucces_fc);

	ref_fc=lookup_widget(gest_fact,"ref_fc_r");
	nom_fc=lookup_widget(gest_fact,"n_p_fc_r");
	carteid_fc=lookup_widget(gest_fact,"n_c_i_fc_r");
	qant_fc=lookup_widget(gest_fact,"spinbutton_fc_r");
	mont_fc=lookup_widget(gest_fact,"mo_fc_r");
	datajout_fc=lookup_widget(gest_fact,"calendar_fc_r");

	strcpy(FC.reference_fc,gtk_entry_get_text(GTK_ENTRY(ref_fc)));
	strcpy(FC.nomprenom_fc,gtk_entry_get_text(GTK_ENTRY(nom_fc)));
	strcpy(FC.numcarte_fc,gtk_entry_get_text(GTK_ENTRY(carteid_fc)));
	FC.quantite_fc=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (qant_fc));
	strcpy(FC.montant_fc,gtk_entry_get_text(GTK_ENTRY(mont_fc)));

	if(strcmp(FC.reference_fc,"")==0)

	{
		        gtk_widget_show (labelref_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelref_fc);
	}

	if(strcmp(FC.nomprenom_fc,"")==0)

	{
		        gtk_widget_show (labelnom_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelnom_fc);
	}

	if(strcmp(FC.numcarte_fc,"")==0)

	{
		        gtk_widget_show (labelnum_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelnum_fc);
	}

	if(strcmp(FC.montant_fc,"")==0)

	{
		        gtk_widget_show (labelmont_fc);
	a=0;

	}else
	{
		   gtk_widget_hide (labelmont_fc);
	}

	if(a==1)
       {

	gtk_calendar_get_date (GTK_CALENDAR(datajout_fc),
                       &a_fc,
                       &m_fc,
                       &jr_fc);
	
	if(choix[0]==1)strcat(resul,"*Veau*");
	if(choix[1]==1)strcat(resul,"*Brebi*");
	if(choix[2]==1)strcat(resul,"*Arboriculture*");
	if(choix[3]==1)strcat(resul,"*serriculture*");
	
	if(Exist_Facture(FC.reference_fc)==1) {
		   gtk_widget_show (labelexiste_fc);

	}
	else{
		   gtk_widget_hide (labelexiste_fc);

	FA=fopen("Facture.txt","a+");
	fprintf(FA,"  %s   %s   %s   %s   %d   %s   %d/%d/%d \n",FC.reference_fc,FC.nomprenom_fc,FC.numcarte_fc,resul,FC.quantite_fc,FC.montant_fc,jr_fc,m_fc+1,a_fc);
	fclose(FA);
	strcpy(resul,"");
        gtk_widget_show (labelsucces_fc);
	GtkWidget *p;
	p=lookup_widget(gest_fact,"treeview1_fc");
	Afficher_Facture(p,"Facture.txt");

}

}
}


void
on_treeview1_fc_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* reference_fc;
	gchar* nomprenom_fc;
	gchar* numcarte_fc;
	GtkTreeModel     *model;

	gchar* produit_fc;
	gint quantite_fc;
	gchar* montant_fc;
	gchar* date_fc;
	Facture FC;
	int x=0;
		 
	GtkWidget *p=lookup_widget(treeview,"treeview1_fc");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
	model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model, &iter,path)){
	//obtention des valeurs de la ligne selectionnée
	gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0,&reference_fc,1,&nomprenom_fc,2,&numcarte_fc,3,&produit_fc,4,
	&quantite_fc,5,&montant_fc,6,&date_fc, -1);//recuperer les informations de la ligne selectionneé

        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"n_p_modif_fc")),nomprenom_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"n_c_i_modif_fc")),numcarte_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"p_modif_fc")),produit_fc);
        gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(treeview,"spinbutton_modif_fc")),quantite_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"mo_modif_fc")),montant_fc);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(treeview,"da_modif_fc")),date_fc);

	GtkWidget* msg=lookup_widget(treeview,"label103_modif_fc");
        gtk_label_set_text(GTK_LABEL(msg),reference_fc);
	       
}
}


void
on_Modifier_fc_clicked                 (GtkWidget      *gest_fact,
                                        gpointer         user_data)
{
	Facture FC;
	FILE*FA=NULL;
        strcpy(FC.reference_fc,gtk_label_get_text(GTK_LABEL(lookup_widget(gest_fact,"label103_modif_fc"))));
        strcpy(FC.nomprenom_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"n_p_modif_fc"))));
        strcpy(FC.numcarte_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"n_c_i_modif_fc"))));
        strcpy(FC.produit_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"p_modif_fc"))));
        FC.quantite_fc =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gest_fact,"spinbutton_modif_fc")));
        strcpy(FC.montant_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"mo_modif_fc"))));
        strcpy(FC.date_fc,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gest_fact,"da_modif_fc"))));		
	
	Supprimer_Facture(FC.reference_fc);
	Ajouter_Facture(FC);

       	Afficher_Facture(lookup_widget(gest_fact,"treeview1_fc"),"Facture.txt");
 	GtkWidget* msg_modif_fc=lookup_widget(gest_fact,"label106_fc");
        gtk_widget_show(msg_modif_fc);
}


void
on_checkbutton1_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(togglebutton))
{choix[0]=1;}else{choix[0]=0;}



}


void
on_checkbutton2_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choix[1]=1;}else{choix[1]=0;}

}


void
on_checkbutton3_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choix[2]=1;}else{choix[2]=0;}

}


void
on_checkbutton4_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(togglebutton))
{choix[3]=1;}else{choix[3]=0;}

}


void
on_AcceuilGestionFacture_clicked       (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_Facture;
	Acceuil=lookup_widget(gest_fact,"Acceuil");
	gtk_widget_hide(Acceuil);
	Gestion_Facture= create_Gestion_Facture ();
	gtk_widget_show(Gestion_Facture);

}


void
on_Actualiser_fc_clicked               (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{

	GtkWidget *p;
	GtkWidget *p1;
	int n;
	GtkWidget *nbA_fc;
	char ch_fc[30];
	
	FILE*FA=NULL;

	nbA_fc=lookup_widget(gest_fact,"labelnb_fc");
	p=lookup_widget(gest_fact,"treeview1_fc");
	p1=lookup_widget(gest_fact,"treeview2_fc");

	n=Afficher_Facture(p,"Facture.txt");
	Afficher_Facture(p1,"Facture.txt");
	sprintf(ch_fc,"%d",n);
	gtk_label_set_text(GTK_LABEL(nbA_fc),ch_fc);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbA_fc);
}


void
on_Supp_fc_clicked                     (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{
	Facture FC;
        GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label_fc_sp;
        gchar* reference_fc;

        label_fc_sp=lookup_widget(gest_fact,"label107_fc");
        p=lookup_widget(gest_fact,"treeview1_fc");

        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
	   gtk_tree_model_get (model,&iter,0,&reference_fc,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           Supprimer_Facture(reference_fc);// supprimer la ligne du fichier
	   gtk_widget_hide (label_fc_sp);
	}else{
                gtk_widget_show (label_fc_sp);

	     }


}


void
on_Chercher_fc_clicked                 (GtkWidget        *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *p1;
	GtkWidget *num_fc;
	GtkWidget *labelnum_fc;
	GtkWidget *nbResultat_fc;
	GtkWidget *message_fc;

	char numcarte_fc[30];
	char chnb_fc[30];
	int a=0,nb;

	num_fc=lookup_widget(gest_fact,"nym_rech_fc");
	labelnum_fc=lookup_widget(gest_fact,"label105_fc");
	p1=lookup_widget(gest_fact,"treeview2_fc");
	strcpy(numcarte_fc,gtk_entry_get_text(GTK_ENTRY(num_fc)));

	if(strcmp(numcarte_fc,"")==0)
	{
	  gtk_widget_show (labelnum_fc);a=0;
	}
	else{
	a=1;
	gtk_widget_hide (labelnum_fc);
	    }

	if(a==0){return;}else{

	nb=Chercher_Facture(p1,"Facture.txt",numcarte_fc);//type entry ecrie par lutilisateur
	/* afficher le nombre de resultats obtenue par la recherche */
	sprintf(chnb_fc,"%d",nb);
	nbResultat_fc=lookup_widget(gest_fact,"label104_fc");
	message_fc=lookup_widget(gest_fact,"label103_fc");
	gtk_label_set_text(GTK_LABEL(nbResultat_fc),chnb_fc);//set_text n'accepte que chaine de caractere 

	gtk_widget_show (nbResultat_fc);
	gtk_widget_show (message_fc);

	                     }

}


void
on_Retour_fc_clicked                   (GtkWidget       *gest_fact,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_Facture;


	Gestion_Facture=lookup_widget(gest_fact,"Gestion_Facture");
	gtk_widget_hide (Gestion_Facture);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);

}


///////************* Gestion de capteur ********************///////

void
on_cvalider_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;

GtkWidget *input1,*input4;

GtkWidget *JOUR;
GtkWidget *MOIS;
GtkWidget *ANNEE;
GtkWidget *radio1;
GtkWidget *radio2;
GtkWidget *radio3;
GtkWidget *radio4;
GtkWidget *label19;

GtkWidget *output;


GSList *List;

GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

char msg[500];

FILE *f=NULL;



input1=lookup_widget(object_graphique,"cidcap");

input4=lookup_widget(object_graphique,"cmarque");
JOUR=lookup_widget(object_graphique,"cjour");
MOIS=lookup_widget(object_graphique,"cmois");
ANNEE=lookup_widget(object_graphique,"cannee");
radio1=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton1");
radio2=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton2");
radio3=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton3");
radio4=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton4");

output=lookup_widget(object_graphique,"clabel19");




List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio1)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data)));}

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio3)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data))); 
else {List = g_slist_next(List); 
strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data)));}



strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));

int i,k=0,j=0;
for (i=0;i<strlen(c.idcapteur);i++)
if (      (isspace(c.idcapteur[i])!=0) ||  (c.idcapteur[i]=='*')    ) k++;
for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir ID capteur "); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==1) 
	{sprintf(msg,"Ce capteur existe ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if (k!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n dans le champ ID du capteur");

	gtk_label_set_text(GTK_LABEL(output),msg); }
else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }			
			
else if (strcmp(c.marque,"")==0) {sprintf(msg,"Veuillez saisir la marque du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else { sprintf(msg,"capteur ayant l ID: %s\n ajoutee avec succes",c.idcapteur); gtk_label_set_text(GTK_LABEL(output),msg);
	ajouter_capteur(c); }

}










void
on_cvalider2_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;
GtkWidget *input;

GtkWidget *output;
char msg[200];




output=lookup_widget(object_graphique,"clabel18");
input=lookup_widget(object_graphique,"cidcapsup");
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));

if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir ID capteur à supprimer"); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==0) 
	{ sprintf(msg,"Ce capteur n'existe pas ");gtk_label_set_text(GTK_LABEL(output),msg); }

else {supprimer_capteur(c);sprintf(msg,"Donnees du capteur ayant l id : %s \n sont supprimées",c.idcapteur);gtk_label_set_text(GTK_LABEL(output),msg); }	 




}















void
on_cvmdf_clicked                       (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{

GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;
GtkWidget *input;
GtkWidget *cmarquemdf;
GtkWidget *output;
GtkWidget *idcapmdf;
char msg[200];

capteur c;


input=lookup_widget(object_graphique,"cidcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
combobox1=lookup_widget(object_graphique,"ccombobox1");
combobox2=lookup_widget(object_graphique,"ccombobox2");
cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");
output=lookup_widget(object_graphique,"clabel17");



	strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(cmarquemdf)));
int i,k=0,j=0;

for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir l ID du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if ( (    gtk_combo_box_get_active(GTK_COMBO_BOX(combobox1))<0   )|| gtk_combo_box_get_active(GTK_COMBO_BOX(combobox2))<0 || strcmp(c.marque,"")==0 ) 

gtk_label_set_text(GTK_LABEL(output),"veuillez saisir les donnees");

else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else 	
{		
	strcpy(c.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmj));
	c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmm));
	c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cma));	
	modifier_capteur(c);
	sprintf(msg,"Donnes du capteur ayant l id : %s \n sont modifiees",c.idcapteur);
	gtk_label_set_text(GTK_LABEL(output),msg) ;	
}


}


void
on_caffmdf_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
capteur c;
capteur e;

GtkWidget *input;
GtkWidget *output;
GtkWidget *label17;
GtkWidget *cmarquemdf;
GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;


char msg[200];

combobox2=lookup_widget(object_graphique,"ccombobox1");
combobox1=lookup_widget(object_graphique,"ccombobox2");


cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");


input=lookup_widget(object_graphique,"cidcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
output=lookup_widget(object_graphique,"clabel17");
if (strcmp(c.idcapteur,"")==0) {sprintf(msg,"Veuillez saisir l ID du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}
else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else {	e=idrechercher(c);
	sprintf(msg,"Modification des donnes du capteur\n ayant l id : %s ",c.idcapteur);
	/*"%s %s %s %s %d %d %d " , e.idcapteur,e.type,e.etat,e.marque,e.dda.jour,e.dda.mois,e.dda.annee);*/
	gtk_label_set_text(GTK_LABEL(output),msg);
	

	
	if (strcmp(e.type,"temperature")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),0);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),1);
	if (strcmp(e.etat,"fonctionnel")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),0);
	else if (strcmp(e.etat,"en-arret")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),1);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),2);
	
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmj),e.dda.jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmm),e.dda.mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cma),e.dda.annee);
	gtk_entry_set_text(GTK_ENTRY(cmarquemdf),e.marque);	}

}















void
on_cafficher_clicked                   (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

treeview1=lookup_widget(object_graphique,"ctreeview1");
afficher_capteur(treeview1);
}


void
on_cbutton1_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
valeur v;
capteur c;
GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *label76;
GtkWidget *radiobutton5;
GtkWidget *radiobutton6;
GtkWidget *calendar1;
guint *y;
guint *m;
guint *d;
  guint year, month, day;
char type[50];
char aaa[50];


entry1=lookup_widget(object_graphique,"centry1");
entry2=lookup_widget(object_graphique,"centry2");
label76=lookup_widget(object_graphique,"clabel76");

radiobutton5=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton5");
radiobutton6=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton6");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton5)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

strcpy(v.idcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(c.idcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(aaa,gtk_entry_get_text(GTK_ENTRY(entry2)));
v.val=atof(aaa);

///////////////////////////////
calendar1=lookup_widget(GTK_WIDGET(object_graphique),"ccalendar1");
gtk_calendar_get_date (GTK_CALENDAR (calendar1),
			 &year, &month, &day);

v.j=day;
v.m=month;
v.a=year;

////////////////////////////
int i,j=0;
for (i = 0;aaa[i] != '\0'; i++)
        if (isdigit(aaa[i])!= 0)
            j++;

c=idrechercher(c);


if (   strcmp(v.idcapteur,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir l ID du capteur");}
else if (rechercher(c)==0) { gtk_label_set_text(GTK_LABEL(label76),"ce capteur n existe pas");}
else if (strcmp(c.etat,"fonctionnel")!=0) {gtk_label_set_text(GTK_LABEL(label76),"Veuillez verifier que ce capteur est fonctionnel");}
else if (strcmp(c.type,type)!=0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez verifier le type correcte de ce capteur");}
else if (strcmp(aaa,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir la valeur ajoutée");}
else if (j==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir une valeur entiére");}
else { gtk_label_set_text(GTK_LABEL(label76),"Valeur ajoutée avec succès"); 
	if (strcmp(type,"temperature")==0) ajouter_temperature(v);
	else ajouter_humidite(v);}









}


void
on_cbutton3_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul type
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
float min,max;
char type[50];

treeview3=lookup_widget(object_graphique,"ctreeview3");
entry3=lookup_widget(object_graphique,"centry3");
entry4=lookup_widget(object_graphique,"centry4");
radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

min=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
max=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"temperature")==0) afficher_temperature(treeview3);
else afficher_humidite(treeview3);



}


void
on_cbutton4_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul capteur
GtkWidget *treeview3;
GtkWidget *entry5;
char id[50];
capteur c;

entry5=lookup_widget(object_graphique,"centry5");
treeview3=lookup_widget(object_graphique,"ctreeview3");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(c.idcapteur,id);
afficher_valeur_capteur(treeview3,c);


}


void
on_cbutton5_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs probleme d un seul type hors un intervalle
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
v.vmax=0;v.vmin=0;
entry3=lookup_widget(object_graphique,"centry3");
entry4=lookup_widget(object_graphique,"centry4");
treeview3=lookup_widget(object_graphique,"ctreeview3");

radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"humidite")==0) afficher_valeur_probleme_hum(treeview3,v);
else afficher_valeur_probleme_temp(treeview3,v);




}


void
on_cbutton6_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//changer type en def si hors l intervalle 
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
GtkWidget *label72;

label72=lookup_widget(object_graphique,"clabel72");

entry3=lookup_widget(object_graphique,"centry3");
entry4=lookup_widget(object_graphique,"centry4");


radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"cradiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));
if (v.vmin==0 && v.vmax==0) gtk_label_set_text(GTK_LABEL(label72),"verifier les valeurs de l intervalle");
else if (strcmp(type,"humidite")==0) {capteur_valeur_defecteux_hum(v);gtk_label_set_text(GTK_LABEL(label72),"Les etats de ces capteur sont changés \nen defectueuex");}
else {capteur_valeur_defecteux_temp(v);gtk_label_set_text(GTK_LABEL(label72),"Les etats de ces capteur sont changés \n en defectueuex");}




}



void
on_cbutton2_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//marque + de cap def 
term t;
char msg[500];
int k;
GtkWidget *label72;

label72=lookup_widget(object_graphique,"clabel72");

marques_def();
marques_def_nbr();
k=max_marque_def();

t=finale(t,k);
strcpy(msg,t.ter);
if (strcmp(msg,"//////////////*")==0) strcpy(msg,"aucun capteur defectueux");
gtk_label_set_text(GTK_LABEL(label72),msg);



}


void
on_ctreeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



	GtkTreeIter iter;
	gchar* idcapteur;
	gchar* type;
	gchar* etat;
	gchar* marque;

	gchar* date;


	capteur c;
	
	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if ( gtk_tree_model_get_iter(model,&iter,path)) {
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&idcapteur,1,&type,2,&etat,3,&marque,4,&date,-1);
	strcpy(c.idcapteur,idcapteur);

	supprimer_capteur(c);
	afficher_capteur(treeview);
	

	}
}
///////////////////////////////gestion equipement////////////////////////////
void
on_acc_gest_capteur_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

	GtkWidget *Acceuil;
	GtkWidget *cinterface;
	Acceuil=lookup_widget(button,"Acceuil");
	gtk_widget_hide(Acceuil);
	cinterface = create_cinterface ();
	gtk_widget_show(cinterface);

}


void
on_ret_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *cinterface;


	cinterface=lookup_widget(button,"cinterface");
	gtk_widget_hide (cinterface);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);
}






void
on_Ajouterequipement_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *Ajouter_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;
        Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
	Ajouter_un_equipement=lookup_widget(objet,"Ajouter_un_equipement");
        gtk_widget_destroy(Gestion_des__equipement_agricole);

	Ajouter_un_equipement=create_Ajouter_un_equipement();
	gtk_widget_show(Ajouter_un_equipement);

}





void
on_supprimerequipement_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Supprimer_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;
        Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
        gtk_widget_destroy(Gestion_des__equipement_agricole);

	Supprimer_un_equipement=create_Supprimer_un_equipement();
	gtk_widget_show(Supprimer_un_equipement);  
}


void
on_ajouteequipe_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
GtkWidget *combo1_eq;
 GtkWidget*radio1; 
GtkWidget*radio2;


radio1=lookup_widget(GTK_WIDGET(objet_graphique),"eqenmarche");
radio2=lookup_widget(GTK_WIDGET(objet_graphique),"eqenpanne");
  
 equipements e;
 DATE d1;
 GtkWidget *Ajouter_un_equipement;
 FILE *f=NULL;
 
Ajouter_un_equipement=lookup_widget(objet_graphique,"Ajouter_un_equipement");
input1=lookup_widget(objet_graphique,"eqtype");
input2=lookup_widget(objet_graphique,"eqmarque");
input3=lookup_widget(objet_graphique,"eqmodel");
input4=lookup_widget(objet_graphique,"eqidentifiant");
input5=lookup_widget(objet_graphique,"eqprix");
JOUR=lookup_widget(objet_graphique,"eqjour");
MOIS=lookup_widget(objet_graphique,"eqmois");
ANNEE=lookup_widget(objet_graphique,"eqannee");
input6=lookup_widget(objet_graphique,"etat");
combo1_eq=lookup_widget(objet_graphique,"eqcombobox3");
strcpy(e.gamme,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1_eq)));
strcpy(e.type,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.modele,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
e.d1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
e.d1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
e.d1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));

  GSList *pList;
    const gchar *sLabel;
//GSList*gtk_radio_button_get_group(GtkRadioButton *radio1);




  /* Récupération de la liste des boutons */
    pList = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio1));
 



    /* Parcours de la liste */
    while(pList)
    {
        /* Le bouton est-il sélectionné */
        if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(pList->data)))
        {
            /* OUI -> on copie le label du bouton */
            sLabel = gtk_button_get_label(GTK_BUTTON(pList->data));
            /* On met la liste a NULL pour sortir de la boucle */
            pList = NULL;
        }
        else
        {
            /* NON -> on passe au bouton suivant */
            pList = g_slist_next(pList);
        }
    }
strcpy(e.etat,sLabel);
if (gtk_combo_box_get_active(GTK_COMBO_BOX(combo1_eq))>=0) ajouter_equipe(e);

}
}


void
on_Retourgestion_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_des__equipement_agricole;


	Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
	gtk_widget_hide (Gestion_des__equipement_agricole);
	Acceuil = create_Acceuil ();
	gtk_widget_show (Acceuil);
}


void
on_Retourajoute_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{       GtkWidget *Gestion_des__equipement_agricole;
        GtkWidget *Ajouter_un_equipement;
	
        Ajouter_un_equipement=lookup_widget(objet,"Ajouter_un_equipement");
        gtk_widget_destroy(Ajouter_un_equipement);

	Gestion_des__equipement_agricole=create_Gestion_des__equipement_agricole();
	gtk_widget_show(Gestion_des__equipement_agricole);

}


void
on_Afficherequipe_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{        
        GtkWidget *Ajouter_un_equipement;
        GtkWidget *Afficher_un_equipement;
	
        Ajouter_un_equipement=lookup_widget(objet,"Ajouter_un_equipement");
        gtk_widget_destroy(Ajouter_un_equipement);

	Afficher_un_equipement=create_Afficher_un_equipement ();
	gtk_widget_show(Afficher_un_equipement);

}


void
on_Affichetreeview_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewequipe; 
treeviewequipe=lookup_widget(objet,"treeviewequipe");
afficher_equipement(treeviewequipe);
}


void
on_Validermodifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

}











void
on_Retoursuppr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Supprimer_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;

        Supprimer_un_equipement=lookup_widget(objet,"Supprimer_un_equipement");

        gtk_widget_destroy(Supprimer_un_equipement);

	Gestion_des__equipement_agricole=create_Gestion_des__equipement_agricole();

	gtk_widget_show(Gestion_des__equipement_agricole);
}


void
on_Modifierequipeon_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
{
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
GtkWidget *combo1_eq;
GtkWidget*radio1; 
GtkWidget*radio2;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

radio1=lookup_widget(GTK_WIDGET(objet_graphique),"eq2enpanne");
radio2=lookup_widget(GTK_WIDGET(objet_graphique),"eq2enmarche");
  
 equipements e;
 DATE d1;
 GtkWidget *Modifier_un_equipement;
 FILE *f=NULL;
 
Modifier_un_equipement=lookup_widget(objet_graphique,"Modifier_un_equipement");
input1=lookup_widget(objet_graphique,"eqmodifetype");
input2=lookup_widget(objet_graphique,"eqmodifemarque");
input3=lookup_widget(objet_graphique,"eqmodifmodele");
input4=lookup_widget(objet_graphique,"eqmodifeiden");
input5=lookup_widget(objet_graphique,"eqmodifeprix");
JOUR=lookup_widget(objet_graphique,"eq2JOUR");
MOIS=lookup_widget(objet_graphique,"eq2MOIS");
ANNEE=lookup_widget(objet_graphique,"eq2ANNEE");

combo1_eq=lookup_widget(objet_graphique,"Combomodifierequipe");
strcpy(e.gamme,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1_eq)));
strcpy(e.type,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.modele,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input4)));
e.d1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
e.d1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
e.d1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
  GSList *pList;
    const gchar *sLabel;




  /* Récupération de la liste des boutons */
    pList = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio1));
 



    /* Parcours de la liste */
    while(pList)
    {
        /* Le bouton est-il sélectionné */
        if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(pList->data)))
        {
            /* OUI -> on copie le label du bouton */
            sLabel = gtk_button_get_label(GTK_BUTTON(pList->data));
            /* On met la liste a NULL pour sortir de la boucle */
            pList = NULL;
        }
        else
        {
            /* NON -> on passe au bouton suivant */
            pList = g_slist_next(pList);
        }
    }
strcpy(e.etat,sLabel);
if (   gtk_combo_box_get_active(GTK_COMBO_BOX(combo1_eq))>=0    ) modifier_equipe(e);

}
}


void
on_Retourmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *Gestion_des__equipement_agricole;
        GtkWidget *Modifier_un_equipement;
	
        Modifier_un_equipement=lookup_widget(objet,"Modifier_un_equipement");
        gtk_widget_destroy(Modifier_un_equipement);

	Gestion_des__equipement_agricole=create_Gestion_des__equipement_agricole();
	gtk_widget_show(Gestion_des__equipement_agricole);
}


void
on_Suprim_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{ 
equipements e;
GtkWidget *inputsupp;
inputsupp=lookup_widget(objet,"suppiden");
strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(inputsupp)));
supprimer_equipe(e); 
}


void
on_Modifierequipement_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
        
         

     GtkWidget *Modifier_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;
         Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
	Modifier_un_equipement=lookup_widget(objet,"Modifier_un_equipement");
        gtk_widget_destroy(Gestion_des__equipement_agricole);

	Modifier_un_equipement=create_Modifier_un_equipement();
	gtk_widget_show(Modifier_un_equipement);








}


void
on_Afficherlesequipe_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *Afficher_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;
         Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
	Afficher_un_equipement=lookup_widget(objet,"Afficher_un_equipement");
        gtk_widget_destroy(Gestion_des__equipement_agricole);

	Afficher_un_equipement=create_Afficher_un_equipement();
	gtk_widget_show(Afficher_un_equipement);
}


void
on_retourdesupp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Supprimer_un_equipement;
	GtkWidget *Gestion_des__equipement_agricole;

        Supprimer_un_equipement=lookup_widget(objet,"Supprimer_un_equipement");

        gtk_widget_destroy(Supprimer_un_equipement);

	Gestion_des__equipement_agricole=create_Gestion_des__equipement_agricole();

	gtk_widget_show(Gestion_des__equipement_agricole);
}


void
on_retourdeaffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Gestion_des__equipement_agricole;
        GtkWidget *Afficher_un_equipement;
	
        Afficher_un_equipement=lookup_widget(objet,"Afficher_un_equipement");
        gtk_widget_destroy(Afficher_un_equipement);

	Gestion_des__equipement_agricole=create_Gestion_des__equipement_agricole();
	gtk_widget_show(Gestion_des__equipement_agricole);


}


void
on_chercherequip_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
FILE *f;
equipements e;
char ch[50];


GtkWidget *output;
char identifiant[50];
char ch1[50],ch2[50],ch3[50],ch4[50],ch5[50],ch6[50],ch7[50];
char j[50],m[50],a[50];
GtkWidget *input1;
GtkWidget  *output1,*output2,*output3,*output4,*output5,*output6,*output7,*output8,*output9;
input1=lookup_widget(objet_graphique,"eqmodifeiden");
strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
output = lookup_widget(objet_graphique, "chercherid") ;
output1=lookup_widget(objet_graphique,"cherchertype");

output2 =lookup_widget(objet_graphique, "cherchermarque");
output3 =lookup_widget(objet_graphique, "cherchermodele");
output4 =lookup_widget(objet_graphique, "cherchergamme");
output5 =lookup_widget(objet_graphique, "chercherprix");
output6 =lookup_widget(objet_graphique, "chercherjour");
output7 =lookup_widget(objet_graphique, "cherchermois");
output8 =lookup_widget(objet_graphique, "chercherannee");
output9 =lookup_widget(objet_graphique, "chercheretat");

f=fopen("equipements.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s  ",ch1,ch2,ch3,ch4,ch5,j,m,a,ch6,ch7)!=EOF)
       { if (strcmp(identifiant,ch5)==0  )
//e.gamme,e.type,e.marque,e.modele,e.identifiant,e.d1.jour,e.d1.mois,e.d1.annee,e.prix,e.etat);
{


sprintf(ch,"l'equipement est trouvé");
gtk_label_set_text(GTK_LABEL(output),ch);

   gtk_label_set_text(GTK_LABEL(output1),ch2);

   gtk_label_set_text(GTK_LABEL(output2),ch3);
   gtk_label_set_text(GTK_LABEL(output3),ch4);
   gtk_label_set_text(GTK_LABEL(output4),ch1);
   
   gtk_label_set_text(GTK_LABEL(output6),j);
   gtk_label_set_text(GTK_LABEL(output7),m);
   gtk_label_set_text(GTK_LABEL(output8),a); 
   gtk_label_set_text(GTK_LABEL(output5),ch6);
   gtk_label_set_text(GTK_LABEL(output9),ch7);

}
else
{
sprintf(ch,"Equipement non existant");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
}
}


void
on_AcceuilGestionplant_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	/*GtkWidget *Acceuil;
	GtkWidget *cinterface;
	Acceuil=lookup_widget(button,"Acceuil");
	gtk_widget_hide(Acceuil);
	cinterface = create_cinterface ();
	gtk_widget_show(cinterface);*/
}


void
on_AcceuilGestionequip_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *Gestion_des__equipement_agricole;
	Acceuil=lookup_widget(button,"Acceuil");
	gtk_widget_hide(Acceuil);
	Gestion_des__equipement_agricole = create_Gestion_des__equipement_agricole ();
	gtk_widget_show(Gestion_des__equipement_agricole);
}


//////////////////////////gestion client///////////////////





void
on_button1_clicked                     (GtkWidget    *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *ajout;
espaceC=lookup_widget(objet,"espaceC");

gtk_widget_destroy(espaceC);
ajout=lookup_widget(objet,"ajout");
ajout=create_ajout();
gtk_widget_show(ajout);

}

void on_ok_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
 GtkWidget *radio1;
  GtkWidget *radio2;
  GtkWidget *Fsortie_ajouter,*Fsortie_ajouter1,*Fsortie_ajouter2,*Fsortie_ajouter3,*Fsortie_ajouter4,*Fsortie_ajouter5,*Fsortie_ajouter6,*Fsortie_ajouter7;
int t1,t2,t3,t4,t5,t6,t7;

 client c;
 GtkWidget *ajout;
GSList *List;

GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

 FILE *f=NULL;
 
ajout=lookup_widget(objet_graphique,"ajout");
input1=lookup_widget(objet_graphique,"carteid");
input2=lookup_widget(objet_graphique,"nom");
input3=lookup_widget(objet_graphique,"prenom");
input4=lookup_widget(objet_graphique,"login");
input5=lookup_widget(objet_graphique,"password");
JOUR=lookup_widget(objet_graphique,"jour");
MOIS=lookup_widget(objet_graphique,"mois");
ANNEE=lookup_widget(objet_graphique,"annee");
input6=lookup_widget(objet_graphique,"num");

input7=lookup_widget(objet_graphique,"adresse");
radio1=lookup_widget(GTK_WIDGET(objet_graphique),"radiobuttoncl1");
radio2=lookup_widget(GTK_WIDGET(objet_graphique),"radiobuttoncl2");
Fsortie_ajouter=lookup_widget(objet_graphique,"Fsortie_ajouter");
Fsortie_ajouter1=lookup_widget(objet_graphique,"Fsortie_ajouter1");
Fsortie_ajouter2=lookup_widget(objet_graphique,"Fsortie_ajouter2");
Fsortie_ajouter3=lookup_widget(objet_graphique,"Fsortie_ajouter3");
Fsortie_ajouter4=lookup_widget(objet_graphique,"Fsortie_ajouter4");
Fsortie_ajouter5=lookup_widget(objet_graphique,"Fsortie_ajouter5");
Fsortie_ajouter6=lookup_widget(objet_graphique,"Fsortie_ajouter6");
Fsortie_ajouter7=lookup_widget(objet_graphique,"Fsortie_ajouter7");


strcpy(c.carteid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.password,gtk_entry_get_text(GTK_ENTRY(input5)));
c.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
c.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(c.num,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input7)));
List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio1)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.sexe,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(c.sexe,gtk_button_get_label(GTK_BUTTON(List->data)));}

t1=numbers(c.carteid);
t2=alphabet(c.nom);
t3=alphabet(c.prenom);
t4=alphanumb(c.login);
t5=alphanumb(c.password);
t6=numbers(c.num);
t7=alphabet(c.adresse);

if(t1==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter),"carte identite ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter),"carte identite false.");

if(t2==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter1),"nom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter1),"nom false.");
if(t3==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter2),"prenom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter2),"prenom false.");
if(t4==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter3),"login ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter3),"login false.");
if(t5==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter4),"password ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter4),"password false.");
if(t6==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter5),"numero ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter5),"numero false.");
if(t7==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter6),"adresse ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter6),"adresse false.");
if ((t1==1)&&(t2==1)&&(t3==1)&&(t4==1)&&(t5==1)&&(t6==1)&&(t7==1))
	{  gtk_label_set_text(GTK_LABEL(Fsortie_ajouter7),"le client a été ajouté.");
	   ajouter_client(c);
	}
else {gtk_label_set_text(GTK_LABEL(Fsortie_ajouter7),"saisir les champs convenablement.");


}

}
void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *suppression;
espaceC=lookup_widget(objet,"espaceC");

gtk_widget_destroy(espaceC);
suppression=lookup_widget(objet,"suppression");
suppression=create_suppression();
gtk_widget_show(suppression);


}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *suppression;
suppression=lookup_widget(objet,"suppression");

gtk_widget_destroy(suppression);
espaceC=lookup_widget(objet,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);


}


void
on_ok2_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *input;
 GtkWidget *Fsortie_supprimer;
 client c;
 FILE *f=NULL;
int t;

input=lookup_widget(objet_graphique,"carteid2");
strcpy(c.carteid,gtk_entry_get_text(GTK_ENTRY(input)));
Fsortie_supprimer=lookup_widget(objet_graphique,"Fsortie_supprimer");
t=numbers(c.carteid);
if (t==1)
	{  gtk_label_set_text(GTK_LABEL(Fsortie_supprimer),"le client a été suppimée.");
   supprimer_client(c);
	}
else {gtk_label_set_text(GTK_LABEL(Fsortie_supprimer),"resaisie correctement carte id.");


}




}


void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *espaceC;
 GtkWidget *ajout;
ajout=lookup_widget(objet,"ajout");

gtk_widget_destroy(ajout);
espaceC=lookup_widget(objet,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);


}


void
on_modifier1_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *modification;
espaceC=lookup_widget(objet,"espaceC");

gtk_widget_destroy(espaceC);
modification=lookup_widget(objet,"modification");
modification=create_modification();
gtk_widget_show(modification);


}


void
on_modifier2_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
 GtkWidget *radio3;
  GtkWidget *radio4;
 client c;
 GtkWidget *modification;
 GtkWidget *sortiemodification,*sortiemodification1,*sortiemodification2,*sortiemodification3,*sortiemodification4,*sortiemodification5,*sortiemodification6,*sortiemodification7;
GSList *List;

GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);
 FILE *f=NULL;
 int t1,t2,t3,t4,t5,t6,t7;
modification=lookup_widget(objet_graphique,"modification1");
input1=lookup_widget(objet_graphique,"carteid1");
input2=lookup_widget(objet_graphique,"nom1");
input3=lookup_widget(objet_graphique,"prenom1");
input4=lookup_widget(objet_graphique,"login1");
input5=lookup_widget(objet_graphique,"password1");
JOUR=lookup_widget(objet_graphique,"jour1");
MOIS=lookup_widget(objet_graphique,"mois1");
ANNEE=lookup_widget(objet_graphique,"annee1");
input6=lookup_widget(objet_graphique,"num1");
input7=lookup_widget(objet_graphique,"adresse1");
radio3=lookup_widget(GTK_WIDGET(objet_graphique),"radiobuttoncl3");
radio4=lookup_widget(GTK_WIDGET(objet_graphique),"radiobuttoncl4");
sortiemodification=lookup_widget(objet_graphique,"sortiemodification");
sortiemodification1=lookup_widget(objet_graphique,"sortiemodification1");
sortiemodification2=lookup_widget(objet_graphique,"sortiemodification2");
sortiemodification3=lookup_widget(objet_graphique,"sortiemodification3");
sortiemodification4=lookup_widget(objet_graphique,"sortiemodification4");
sortiemodification5=lookup_widget(objet_graphique,"sortiemodification5");
sortiemodification6=lookup_widget(objet_graphique,"sortiemodification6");
sortiemodification7=lookup_widget(objet_graphique,"sortiemodification7");
strcpy(c.carteid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.login,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.password,gtk_entry_get_text(GTK_ENTRY(input5)));
c.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
c.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(c.num,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input7)));
List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio3)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.sexe,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(c.sexe,gtk_button_get_label(GTK_BUTTON(List->data)));}
t1=numbers(c.carteid);
t2=alphabet(c.nom);
t3=alphabet(c.prenom);
t4=alphanumb(c.login);
t5=alphanumb(c.password);
t6=numbers(c.num);
t7=alphabet(c.adresse);

if(t1==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification),"ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification)," false.");

if(t2==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification1),"nom ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification1),"nom false.");
if(t3==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification2),"prenom ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification2),"prenom false.");
if(t4==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification3),"login ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification3),"login false.");
if(t5==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification4),"password ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification4),"password false.");
if(t6==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification5),"numero ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification5),"numero false.");
if(t7==1) {
   gtk_label_set_text(GTK_LABEL(sortiemodification6),"adresse ok.");
}else 
gtk_label_set_text(GTK_LABEL(sortiemodification6),"adresse false.");
if ((t1==1)&&(t2==1)&&(t3==1)&&(t4==1)&&(t5==1)&&(t6==1)&&(t7==1))
	{  gtk_label_set_text(GTK_LABEL(sortiemodification7),"le client a été modifie.");
	   modifier_client(c);
	}
else {gtk_label_set_text(GTK_LABEL(sortiemodification7),"saisir les champs convenablement.");


}

}


void
on_rechercher1_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{FILE *f;
client c;
char ch[50];


GtkWidget *output;
char carteid[50];
char ch1[50],ch2[50],ch3[50],ch4[50],ch5[50],ch6[50],ch7[50],ch8[50];
char j[50],m[50],a[50];
GtkWidget *input1;
GtkWidget  *output1,*output2,*output3,*output4,*output5,*output6,*output7,*output8,*output9,*output10;
input1=lookup_widget(objet_graphique,"carteid1");
strcpy(carteid,gtk_entry_get_text(GTK_ENTRY(input1)));
output = lookup_widget(objet_graphique, "label41") ;
output1=lookup_widget(objet_graphique,"label33");

output2 =lookup_widget(objet_graphique, "label34");
output3 =lookup_widget(objet_graphique, "label35");
output4 =lookup_widget(objet_graphique, "label36");
output5 =lookup_widget(objet_graphique, "label37");
output9 =lookup_widget(objet_graphique, "label63");
output10 =lookup_widget(objet_graphique, "label64");
output6 =lookup_widget(objet_graphique, "label388");
output7 =lookup_widget(objet_graphique, "label39");
output8 =lookup_widget(objet_graphique, "label40");
f=fopen("client.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s ",ch1,ch2,ch3,ch4,ch5,j,m,a,ch6,ch7,ch8)!=EOF)
       { if (strcmp(carteid,ch1)==0  )

{


sprintf(ch,"client trouvable");
gtk_label_set_text(GTK_LABEL(output),ch);

   gtk_label_set_text(GTK_LABEL(output1),ch2);

   gtk_label_set_text(GTK_LABEL(output2),ch3);
   gtk_label_set_text(GTK_LABEL(output3),ch4);
   gtk_label_set_text(GTK_LABEL(output4),ch5);
   
   gtk_label_set_text(GTK_LABEL(output5),j);
   gtk_label_set_text(GTK_LABEL(output9),m);
   gtk_label_set_text(GTK_LABEL(output10),a); 
   gtk_label_set_text(GTK_LABEL(output6),ch6);
   gtk_label_set_text(GTK_LABEL(output7),ch7);
   gtk_label_set_text(GTK_LABEL(output8),ch8);
}
else
{
sprintf(ch,"client non trouvable");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
}
}


void
on_retour3_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *modification;
modification=lookup_widget(objet,"modification");

gtk_widget_destroy(modification);
espaceC=lookup_widget(objet,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);


}


void
on_affichetree_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1; 
treeview1=lookup_widget(objet,"ctreeview1");
afficher_client(treeview1);
}


void
on_Afficheliste_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceC;
 GtkWidget *treeclient;
espaceC=lookup_widget(objet,"espaceC");

gtk_widget_destroy(espaceC);
treeclient=lookup_widget(objet,"treeclient");
treeclient=create_treeclient();
gtk_widget_show(treeclient);
}


void
on_Retrourdetree_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceC;
 GtkWidget *treeclient;
treeclient=lookup_widget(objet,"treeclient");

gtk_widget_destroy(treeclient);
espaceC=lookup_widget(objet,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);
}





void
on_afficherec_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2; 
treeview2=lookup_widget(button,"ctreeview2");
afficher_reclamation(treeview2);
}


void
on_voirrec_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *recladmin;
reclamation r;
char carteid[50];
char ch1[50],ch2[50],ch6[50],ch[50];
int j,m,a;
GtkWidget *output1,*output2,*output3,*output,*jour,*mois,*annee;
FILE *f=NULL;
recladmin=lookup_widget(objet_graphique,"recladmin");
output=lookup_widget(objet_graphique,"contenue1");
output1=lookup_widget(objet_graphique,"carteidrec1");
jour=lookup_widget(objet_graphique,"recljour1");
mois=lookup_widget(objet_graphique,"reclmois1");
annee=lookup_widget(objet_graphique,"reclannee1");
strcpy(carteid,gtk_entry_get_text(GTK_ENTRY(output1)));
r.dr.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
r.dr.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
r.dr.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
f=fopen("envoireclamation.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %d %d %d %s  ",ch1,ch2,&j,&m,&a,ch6)!=EOF)
       { if (strcmp(carteid,ch1)==0 &&(r.dr.jour==j)&&(r.dr.mois==m)&&(r.dr.annee==a) )






   gtk_label_set_text(GTK_LABEL(output),ch6);

   
else
{
sprintf(ch,"client non trouvable");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
}
}



void
on_envoyerrecl_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
 
  GtkWidget *Fsortie_reclamation,*Fsortie_reclamation1,*Fsortie_reclamation2,*Fsortie_reclamation3;
int t1,t2,t3;

 reclamation r;
 GtkWidget *recladmin;

 FILE *f=NULL;
 client c;
recladmin=lookup_widget(objet_graphique,"recladmin");
input1=lookup_widget(objet_graphique,"carteidrec");
input2=lookup_widget(objet_graphique,"sujetrec");
JOUR=lookup_widget(objet_graphique,"recljour");
MOIS=lookup_widget(objet_graphique,"reclmois");
ANNEE=lookup_widget(objet_graphique,"reclannee");
input3=lookup_widget(objet_graphique,"contenuerec");


Fsortie_reclamation=lookup_widget(objet_graphique,"sortiereclamation");
Fsortie_reclamation1=lookup_widget(objet_graphique,"sortiereclamation1");
Fsortie_reclamation2=lookup_widget(objet_graphique,"sortiereclamation2");
Fsortie_reclamation3=lookup_widget(objet_graphique,"sortiereclamation3");

strcpy(r.carteid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.sujet,gtk_entry_get_text(GTK_ENTRY(input2)));



r.dr.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
r.dr.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
r.dr.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(r.contenue,gtk_entry_get_text(GTK_ENTRY(input3)));

t1=numbers(r.carteid);
t2=alphabet(r.sujet);
t3=alphabet(r.contenue);
if(t1==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation)," false.");
if(t2==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation2)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation2)," false.");
if(t3==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation3)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation3)," false.");


if ((t1==1)&&(recherchercl(r.carteid)==1)&&(t2==1)&&(t3==1))
	{  gtk_label_set_text(GTK_LABEL(Fsortie_reclamation1),"reclamation repondue.");
	   ajouter_reclamation(r);
	}
else {gtk_label_set_text(GTK_LABEL(Fsortie_reclamation1),"mal saisie .");


}



}

void
on_reclamationadmin_clicked            (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *recladmin;
espaceC=lookup_widget(objet,"espaceC");

gtk_widget_destroy(espaceC);
recladmin=lookup_widget(objet,"recladmin");
recladmin=create_recladmin();
gtk_widget_show(recladmin);

}




void
on_reclam_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *input1,*input2,*input3;
 GtkWidget *JOUR;
 GtkWidget *MOIS;
 GtkWidget *ANNEE;
 
  GtkWidget *Fsortie_reclamation,*Fsortie_reclamation1,*Fsortie_reclamation2,*Fsortie_reclamation3;
int t1,t2,t3;

 reclamation r;
 GtkWidget *reclclient;

 FILE *f=NULL;
 
reclclient=lookup_widget(objet_graphique,"reclclient");
input1=lookup_widget(objet_graphique,"entry5recclient");
input2=lookup_widget(objet_graphique,"entry7recclient");
JOUR=lookup_widget(objet_graphique,"recljour");
MOIS=lookup_widget(objet_graphique,"reclmois");
ANNEE=lookup_widget(objet_graphique,"reclannee");
input3=lookup_widget(objet_graphique,"entry6recclient");


Fsortie_reclamation=lookup_widget(objet_graphique,"label98rec");
Fsortie_reclamation3=lookup_widget(objet_graphique,"label99rec");
Fsortie_reclamation2=lookup_widget(objet_graphique,"label100rec");
Fsortie_reclamation1=lookup_widget(objet_graphique,"label101rec");

strcpy(r.carteid,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.sujet,gtk_entry_get_text(GTK_ENTRY(input2)));



r.dr.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
r.dr.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
r.dr.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(r.contenue,gtk_entry_get_text(GTK_ENTRY(input3)));

t1=numbers(r.carteid);
t2=alphabet(r.sujet);
t3=alphabet(r.contenue);
if(t1==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation)," false.");
if(t2==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation2)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation2)," false.");
if(t3==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_reclamation3)," ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_reclamation3)," false.");


if ((t1==1)&&(recherchercl(r.carteid)==1)&&(t2==1)&&(t3==1))
	{  gtk_label_set_text(GTK_LABEL(Fsortie_reclamation1),"reclamation envoyee.");
	   ajouter_reclamation1(r);
	}
else {gtk_label_set_text(GTK_LABEL(Fsortie_reclamation1),"mal saisie .");


}



}


void
on_quiitter_clicked                    (GtkWidget     *objet,
                                        gpointer         user_data)
{
 GtkWidget *reclclient;
reclclient=lookup_widget(objet,"reclclient");

gtk_widget_destroy(reclclient);


}


void
on_retourrec_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *espaceC;
 GtkWidget *recladmin;
recladmin=lookup_widget(objet,"recladmin");

gtk_widget_destroy(espaceC);
espaceC=lookup_widget(objet,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);


}


void
on_retour31modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *espaceC;
 GtkWidget *modification;
modification=lookup_widget(button,"modification");

gtk_widget_destroy(modification);
espaceC=lookup_widget(button,"espaceC");
espaceC=create_espaceC();
gtk_widget_show(espaceC);

}



void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *Acceuil;
	GtkWidget *espaceC;
	Acceuil=lookup_widget(button,"Acceuil");
	gtk_widget_destroy(Acceuil);
	espaceC = create_espaceC ();
	gtk_widget_show(espaceC);


}




void
on_retourclient_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{


	GtkWidget *Acceuil;
	GtkWidget *espaceC;
	espaceC=lookup_widget(button,"espaceC");
	gtk_widget_destroy(espaceC);
	Acceuil = create_Acceuil ();
	gtk_widget_show(Acceuil);
}


void
on_Afficher_cli_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview_cli; 
treeview_cli=lookup_widget(button,"treeview_cli");
afficher_client(treeview_cli);
}


void
on_buttonconnect_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *authentification;
GtkWidget *Acceuil;
GtkWidget *reclclient;


authen au;
char log[50],pass[50];
int rol;
client c;
 FILE *f=NULL;
int b=1;
GtkWidget *input1,*input2,*ROLE,*label399,*label400,*label401;
authentification=lookup_widget(objet_graphique,"authentification");
input1=lookup_widget(objet_graphique,"loginaut");
input2=lookup_widget(objet_graphique,"passwordaut");
ROLE=lookup_widget(objet_graphique,"roleaut");
label399=lookup_widget(objet_graphique,"label");
label400=lookup_widget(objet_graphique,"label400");
label401=lookup_widget(objet_graphique,"label401");

authentification=lookup_widget(objet_graphique,"authentification");
strcpy(au.login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(au.password,gtk_entry_get_text(GTK_ENTRY(input2)));
au.role=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ROLE));

if(strcmp(au.login,"")==0){
		        gtk_widget_show (label400);
	b=0;

	}else
	{
		   gtk_widget_hide (label400);
	}
if(strcmp(au.password,"")==0){
		        gtk_widget_show (label401);
	b=0;

	}else
	{
		   gtk_widget_hide (label401);
	}


if (au.role==1)
{
f=fopen("client.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %d %d %d %s %s %s ",c.carteid,c.nom,c.prenom,c.login,c.password,&c.d.jour,&c.d.mois,&c.d.annee,c.num,c.adresse,c.sexe)!=EOF)
       { if ((strcmp(au.login,c.login)==0) &&(strcmp(au.password,c.password)==0 ))
       {

gtk_widget_destroy(authentification);
reclclient=lookup_widget(objet_graphique,"reclclient");
reclclient=create_reclclient();
gtk_widget_show(reclclient);
     
}else

gtk_label_set_text(GTK_LABEL(label399),"client non trouvable ..consulter administration");
}
fclose(f);
}
}else if (au.role==2)
{f=fopen("admin.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %d  ",log,pass,&rol)!=EOF)
 { if ((strcmp(au.login,log)==0) &&(strcmp(au.password,pass)==0 ))
       {

gtk_widget_destroy(authentification);
Acceuil=lookup_widget(objet_graphique,"Acceuil");
Acceuil=create_Acceuil();
gtk_widget_show(Acceuil);
     
}else
gtk_label_set_text(GTK_LABEL(label399),"accees admin false");
}
fclose(f);

}

}
}





void
on_buttondec_tr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *authentification;
	GtkWidget *Gestion_Facture;
	
	Gestion_Facture=lookup_widget(objet,"Gestion_Facture");
	gtk_widget_destroy(Gestion_Facture);
	authentification = create_authentification ();
	gtk_widget_show(authentification);

}


void
on_button34_fc_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *authentification;
	GtkWidget *Gestion_Troupeau;
	
	Gestion_Troupeau=lookup_widget(objet,"Gestion_Troupeau");
	gtk_widget_destroy(Gestion_Troupeau);
	authentification = create_authentification ();
	gtk_widget_show(authentification);
}


void
on_button35_eq_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
 	GtkWidget *authentification;
	GtkWidget *Gestion_des__equipement_agricole;
	
	Gestion_des__equipement_agricole=lookup_widget(objet,"Gestion_des__equipement_agricole");
	gtk_widget_destroy(Gestion_des__equipement_agricole);
	authentification = create_authentification ();
	gtk_widget_show(authentification);

}


void
on_button24_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *recladmin;
	GtkWidget *espaceC;
	
	recladmin=lookup_widget(button,"recladmin");
	gtk_widget_destroy(recladmin);
	espaceC = create_espaceC ();
	gtk_widget_show(espaceC);


}


void
on_acceuilouvre_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil;
	GtkWidget *windowMenu;
	
	Acceuil=lookup_widget(button,"Acceuil");
	gtk_widget_destroy(Acceuil);
	windowMenu = create_windowMenu ();
	gtk_widget_show(windowMenu);

}


void
on_ajouet_ouvrier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier o;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8, *input9, *input10, *input11, *input12, *input14, *input13;
GtkWidget *windowAjout;
GSList *pList;
const gchar *sLabel;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

GtkWidget *buttonradio1, *buttonradio2;
windowAjout=lookup_widget(objet,"windowAjout");
buttonradio1=lookup_widget(GTK_WIDGET(objet),"radiobutton1");
buttonradio2=lookup_widget(GTK_WIDGET(objet),"radiobutton2");


     pList = gtk_radio_button_get_group(GTK_RADIO_BUTTON(buttonradio1));

  //   Parcours de la liste /
    while(pList)
    {
        /// Le bouton est-il sélectionné /
        if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(pList->data)))
        {
            /// OUI -> on copie le label du bouton ///
            sLabel = gtk_button_get_label(GTK_BUTTON(pList->data));
            /// On met la liste a NULL pour sortir de la boucle /
            pList = NULL;
        }
        else
        {
            /// NON -> on passe au bouton suivant// 
            pList = g_slist_next(pList);
        }
    }

input6=lookup_widget(objet,"entrynci");
input1=lookup_widget(objet,"entryNom");
input2=lookup_widget(objet,"entryPrenom");
//input3=lookup_widget(objet,"sexe");
input4=lookup_widget(objet,"combobox1");
input5=lookup_widget(objet,"entryAdresse");

input7=lookup_widget(objet,"entryNum_tel");
input8=lookup_widget(objet,"spinbuttonJour");
input9=lookup_widget(objet,"spinbuttonMois");
input10=lookup_widget(objet,"spinbuttonannee");
input11=lookup_widget(objet,"entryLogin");
input12 =lookup_widget(objet,"entryPassword");
input13 =lookup_widget(objet,"entryConfirmation");

strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
//strcpy(o.sexe,gtk_entry_get_text(GTK_ENTRY(input3)));
//strcpy(,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(o.civilite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(o.nci,gtk_entry_get_text(GTK_ENTRY(input6)));


strcpy(o.num_tel,gtk_entry_get_text(GTK_ENTRY(input7)));
o.d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input8));
o.d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input9));
o.d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input10));
strcpy(o.login,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(o.password,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(o.confirmation,gtk_entry_get_text(GTK_ENTRY(input13)));

//char sx[20];
strcpy(o.sexe,sLabel);
ajouter_ouvrier(o);
}


void
on_button34o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button33o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button37o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button38o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button40o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button36o_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAjout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAjout;
	GtkWidget *windowMenu;
	
	windowMenu=lookup_widget(button,"windowMenu");
	gtk_widget_destroy(windowMenu);
	windowAjout = create_windowAjout ();
	gtk_widget_show(windowAjout);


}

