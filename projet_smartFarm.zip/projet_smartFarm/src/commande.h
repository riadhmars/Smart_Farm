#include<gtk/gtk.h>


typedef struct 
{  
   char login[50];
   char password[50];
   int role;

}authen;
typedef struct 
{int jour;
 int mois;
 int annee;
}DATE2; 
typedef struct
{  char carteid [50];
   char nom[50];
   char prenom[50];
   char login[50];
   char password[50];
   DATE2 d;
   char num[50];
   char adresse[60];
   char sexe[50];

}clientc;
void ajouter_authen(authen au);
