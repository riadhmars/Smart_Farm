#ifdef HAVE_CONFIG_H
#	include <config.h>
#endif




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "travaill.h"
#include <gtk/gtk.h>
enum
{	
	ENOM,
	EPRENOM,
	ECIVILITE,
	ESEXE,
	ENCI,
	EADRESSE,
	ENUM_TEL,
	EJ,
	EM,
	EA,
	ELOG,
	EPASW,
	ECONF,
	COLUMNS,
};
void ajouter_ouvrier(ouvrier o)
{
FILE *f;
f=fopen("travailleur.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n",o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel);
}
fclose(f);
}
void afficher_ouvrier(GtkWidget *liste)
{	
	ouvrier o;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn  *column;
	GtkTreeIter *iter;
	GtkListStore *store;
	char nom[30];
	char prenom[30];
	char civilite[10];
	char sexe[10];
	char nci[30];
	char adresse[30];
	char num_tel[10];
	char login[10];
	char password[10];
	char confirmation[10];
	int j,m,a;
	store=NULL;
	FILE *f;
	store= gtk_tree_view_get_model(liste);

	if(store==NULL){

	renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("civilite",renderer,"text",ECIVILITE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nci",renderer,"text",ENCI,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",EADRESSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("j",renderer,"text",EJ,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("m",renderer,"text",EM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("a",renderer,"text",EA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("login",renderer,"text",ELOG,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",EPASW,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("confirmation",renderer,"text",ECONF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("num_tel",renderer,"text",ENUM_TEL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	}
store=gtk_list_store_new (COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("travailleur.txt","r");
if(f==NULL)
{
  return;
}
else
{
	f=fopen("travailleur.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n",nci,nom,prenom,civilite,sexe,adresse,&j,&m,&a,login,password,confirmation,num_tel)!=EOF)
	{ 
		gtk_list_store_append (store, &iter);
	gtk_list_store_set(store, &iter,ENCI,nci,ENOM,nom,EPRENOM,prenom,ECIVILITE,civilite,ESEXE,sexe,EADRESSE,adresse,EJ,j,EM,m,EA,a,ELOG,login,EPASW,password,ECONF,confirmation,ENUM_TEL,num_tel,-1);
	}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void supprimer_ouvrier(ouvrier o)
{
ouvrier o2;
FILE *f,*h;

f=fopen("travailleur.txt","r");
h=fopen("travailleur2.txt","w");
if(f==NULL || h==NULL )
	return;

        else
	{
 while(fscanf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s   \n",o2.nci,o2.nom,o2.prenom,o2.civilite,o2.sexe,o2.adresse,o2.d.j,o2.d.m,o2.d.a,o2.login,o2.password,o2.confirmation,o2.num_tel)!=EOF)
{
	if(strcmp(o.nom,o2.nom)!=0 || strcmp(o.prenom,o2.prenom)!=0 ||strcmp(o.civilite,o2.civilite)!=0 || strcmp(o.sexe,o2.sexe)!=0 || strcmp(o.nci,o2.nci)!=0 || strcmp(o.adresse,o2.adresse)!=0 || strcmp(o.num_tel,o2.num_tel)!=0 || (o.d.j,o2.d.j)!=0 ||(o.d.m,o2.d.m)!=0 ||(o.d.a,o2.d.a)!=0 || strcmp(o.login,o2.login) || strcmp(o.password,o2.password) || strcmp(o.confirmation,o2.confirmation)!=0)


	fprintf(h,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n",o2.nom,o2.prenom,o2.civilite,o2.sexe,o2.nci,o2.adresse,o2.num_tel,o2.d.j,o2.d.m,o2.d.a,o2.login,o2.password,o2.confirmation);
}

   fclose(f);
   fclose(h);
remove("travailleur.txt");
rename("travailleur2.txt","users.txt");
}
}
void rechercher_ouvrier(ouvrier o)
{
FILE *f;
char nci[30];
f=fopen("travailleur.txt","r");
if(f==NULL)
   return;
else{
	while(fscanf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n", o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel)!=EOF)
 if(strcmp(nci,o.nci)!=0)
	fprintf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n",o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel);
	
}
fclose(f);
}
void modifier_ouvrier(ouvrier o)
{
FILE *f;
char nci[30];
f=fopen("travailleur.txt","r");
if(f==NULL)
	return;
else{
	while(fscanf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n", o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel)!=EOF)
if(strcmp(nci,o.nci)!=0)
fprintf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n",o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel);
fscanf(f,"%s %s %s %s %s %s %d/%d/%d %s %s %s %s \n", o.nci,o.nom,o.prenom,o.civilite,o.sexe,o.adresse,o.d.j,o.d.m,o.d.a,o.login,o.password,o.confirmation,o.num_tel);
}
fclose(f);
}
