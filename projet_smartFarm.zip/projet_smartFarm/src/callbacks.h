#include <gtk/gtk.h>


void
on_button_tr_ajouter_clicked           (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_treeview1_tr_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modifiet_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_supprime_TR_clicked                 (GtkWidget      *gest_trou,
                                        gpointer         user_data);

void
on_button_chercher_tr_clicked          (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_AcceuilGestionTroupeau_clicked      (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_button_Actualise_Troupeau_clicked   (GtkWidget       *gest_trou,
                                        gpointer         user_data);

void
on_button_ret_tr_clicked               (GtkWidget        *gest_trou,
                                        gpointer         user_data);
///////////////////////////////////////////////////////////

void
on_Retour_fc_clicked                   (GtkWidget        *gest_fact,
                                        gpointer         user_data);

void
on_Ajouter_fc_clicked                  (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_treeview1_fc_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Modifier_fc_clicked                 (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_checkbutton1_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_fc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AcceuilGestionFacture_clicked       (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Actualiser_fc_clicked               (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Supp_fc_clicked                     (GtkWidget        *gest_fact,
                                        gpointer         user_data);

void
on_Chercher_fc_clicked                 (GtkWidget       *gest_fact,
                                        gpointer         user_data);

void
on_Retour_fc_clicked                   (GtkWidget        *gest_fact,
                                        gpointer         user_data);


////////////////////////////////////////////////
void
on_cvalider_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);






void
on_cvalider2_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data);









void
on_cvmdf_clicked                       (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_caffmdf_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);










/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
*/







void
on_cafficher_clicked                   (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton1_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton3_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton4_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton5_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton6_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_cbutton2_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data);

void
on_ctreeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_acc_gest_capteur_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ret_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data);





void
on_Ajouterequipement_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_Modifierequipement_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_supprimerequipement_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouteequipe_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Retourgestion_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retourajoute_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficherequipe_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Affichetreeview_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Validermodifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_Retoursuppr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Modifierequipeon_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Retourmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Suprim_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_Afficherlesequipe_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourdesupp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourdeaffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercherequip_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_AcceuilGestionplant_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_AcceuilGestionequip_clicked         (GtkButton       *button,
                                        gpointer         user_data);



void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ok_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ok2_clicked                         (GtkWidget      *Fsortie_supprimer,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier2_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_rechercher1_clicked                 (GtkWidget      *objet_graphiques,
                                        gpointer         user_data);

void
on_retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichetree_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficheliste_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retrourdetree_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reclamationadmin_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficherec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_voirrec_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_envoyerrecl_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_reclam_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_quiitter_clicked                    (GtkWidget     *objet,
                                        gpointer         user_data);

void
on_retourrec_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_retour31modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_retourclient_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Afficher_cli_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconnect_clicked               (GtkWidget        *objet_graphique,
                                        gpointer         user_data);



void
on_buttondec_tr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button34_fc_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button35_eq_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button24_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_acceuilouvre_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouet_ouvrier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button34o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button33o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button37o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button38o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button40o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button36o_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
