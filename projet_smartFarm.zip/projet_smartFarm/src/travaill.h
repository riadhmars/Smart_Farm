#include<gtk/gtk.h>
typedef struct{
int h;
int min;
}heure;
typedef struct{
int j;
int m;
int a;
}date3;
typedef struct{
char nom[30];
char prenom[30];
char civilite[10];
char sexe[10];
char nci[30];
char adresse[30];
char login[10];
char password[10];
char confirmation[10];
char num_tel[10];
date3 d;
date3 r;
date3 v;
heure h1;
}ouvrier;
void ajouter_ouvrier(ouvrier o);
void afficher_ouvrier(GtkWidget *liste);
void supprimer_ouvrier(ouvrier o);
void rechercher_ouvrier(ouvrier o);
void modifier_ouvrier(ouvrier o);
