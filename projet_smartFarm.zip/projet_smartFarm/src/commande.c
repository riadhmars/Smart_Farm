#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "commande.h"
#include <gtk/gtk.h>





void ajouter_authen(authen au)
{FILE *f ;
f=fopen("authentification.txt","a+");
if(f!=NULL)
{fprintf(f,"%s %s %d  \n ",au.login,au.password,au.role);
fclose(f);
}
}

